<?php
/** 
Plugin Name: Prometheus User Submitted Content
Plugin URI: http://codecanyon.net/user/coderevolution/portfolio
Description: This plugin will give your users the power to publish posts on your website.
Author: CodeRevolution
Version: 1.2
Author URI: https://codecanyon.net/user/coderevolution
*/
defined( 'ABSPATH' ) or die();
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/prometheus/master/info.json", __FILE__, "prometheus-user-submitted-posts");
add_action('admin_menu', 'prometheus_register_my_custom_menu_page');
add_action('network_admin_menu', 'prometheus_register_my_custom_menu_page');
function prometheus_register_my_custom_menu_page()
{
    add_menu_page('Prometheus User Submitted Content', 'Prometheus User Submitted Content', 'manage_options', 'prometheus_admin_settings', 'prometheus_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('prometheus_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'prometheus_admin_settings');
    add_submenu_page('prometheus_admin_settings', 'Submitted Posts Statistics', 'Submitted Posts Statistics', 'manage_options', 'prometheus_statistics_page', 'prometheus_statistics_page');
    add_submenu_page('prometheus_admin_settings', 'Form Default Texts', 'Form Default Texts', 'manage_options', 'prometheus_default_texts', 'prometheus_default_texts');
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'prometheus_add_settings_link');
function prometheus_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=prometheus_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

function prometheus_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
register_activation_hook(__FILE__, 'prometheus_activation_callback');
function prometheus_activation_callback($default = FALSE)
{
    if (!get_option('prometheus_Main_Settings') || $default) {
        $all_cats   = array();
        $cat_args   = array(
            'orderby' => 'name',
            'hide_empty' => 0,
            'order' => 'ASC'
        );
        $categories = get_categories($cat_args);
        foreach ($categories as $category) {
            $all_cats[] = $category->term_id;
        }
        $prometheus_Main_Settings = array(
            'prometheus_enabled' => 'on',
            'need_login' => 'on',
            'need_login_message' => 'Only registered users are allowed to submit posts!',
            'anon_users_name' => '',
            'user_name' => 'ShowRequire',
            'user_email' => 'ShowRequire',
            'user_url' => 'Show',
            'post_title' => 'ShowRequire',
            'post_tags' => 'Hide',
            'post_category' => 'ShowRequire',
            'post_captcha' => 'Hide',
            'post_image' => 'Hide',
            'post_content' => 'ShowRequire',
            'captcha_answer' => '0',
            'captcha_question' => '57-57=?',
            'redirect_url' => '',
            'redirect' => '',
            'rich_editor' => 'on',
            'submit_status' => 'pending',
            'failed_message' => '',
            'success_message' => '',
            'unique_title' => '',
            'email_alert_address' => '',
            'email_alert' => '',
            'redirect_url_fail' => '',
            'redirect_to_post' => '',
            'spam_protect' => '',
            'ban_names' => '',
            'censor_words' => '4r5e, 5h1t, 5hit, a55, anal, anus, ar5e, arrse, arse, ass, ass-fucker, asses, assfucker, assfukka, asshole, assholes, asswhole, a_s_s, b!tch, b00bs, b17ch, b1tch, ballbag, balls, ballsack, bastard, beastial, beastiality, bellend, bestial, bestiality, bi+ch, biatch, bitch, bitcher, bitchers, bitches, bitchin, bitching, bloody, blow job, blowjob, blowjobs, boiolas, bollock, bollok, boner, boob, boobs, booobs, boooobs, booooobs, booooooobs, breasts, buceta, bugger, bum, bunny fucker, butt, butthole, buttmuch, buttplug, c0ck, c0cksucker, carpet muncher, cawk, chink, cipa, cl1t, clit, clitoris, clits, cnut, cock, cock-sucker, cockface, cockhead, cockmunch, cockmuncher, cocks, cocksuck , cocksucked , cocksucker, cocksucking, cocksucks , cocksuka, cocksukka, cok, cokmuncher, coksucka, coon, cox, crap, cum, cummer, cumming, cums, cumshot, cunilingus, cunillingus, cunnilingus, cunt, cuntlick , cuntlicker , cuntlicking , cunts, cyalis, cyberfuc, cyberfuck , cyberfucked , cyberfucker, cyberfuckers, cyberfucking , d1ck, damn, dick, dickhead, dildo, dildos, dink, dinks, dirsa, dlck, dog-fucker, doggin, dogging, donkeyribber, doosh, duche, dyke, ejaculate, ejaculated, ejaculates , ejaculating , ejaculatings, ejaculation, ejakulate, f u c k, f u c k e r, f4nny, fag, fagging, faggitt, faggot, faggs, fagot, fagots, fags, fanny, fannyflaps, fannyfucker, fanyy, fatass, fcuk, fcuker, fcuking, feck, fecker, felching, fellate, fellatio, fingerfuck , fingerfucked , fingerfucker , fingerfuckers, fingerfucking , fingerfucks , fistfuck, fistfucked , fistfucker , fistfuckers , fistfucking , fistfuckings , fistfucks , flange, fook, fooker, fuck, fucka, fucked, fucker, fuckers, fuckhead, fuckheads, fuckin, fucking, fuckings, fuckingshitmotherfucker, fuckme , fucks, fuckwhit, fuckwit, fudge packer, fudgepacker, fuk, fuker, fukker, fukkin, fuks, fukwhit, fukwit, fux, fux0r, f_u_c_k, gangbang, gangbanged , gangbangs , gaylord, gaysex, goatse, god-dam, god-damned, goddamn, goddamned, hardcoresex , hell, heshe, hoar, hoare, hoer, homo, hore, horniest, horny, hotsex, jack-off , jackoff, jap, jerk-off , jism, jiz , jizm , jizz, kawk, knob, knobead, knobed, knobend, knobhead, knobjocky, knobjokey, kock, kondum, kondums, kum, kummer, kumming, kums, kunilingus, l3i+ch, l3itch, labia, lmfao, lust, lusting, m0f0, m0fo, m45terbate, ma5terb8, ma5terbate, masochist, master-bate, masterb8, masterbat*, masterbat3, masterbate, masterbation, masterbations, masturbate, mo-fo, mof0, mofo, mothafuck, mothafucka, mothafuckas, mothafuckaz, mothafucked , mothafucker, mothafuckers, mothafuckin, mothafucking , mothafuckings, mothafucks, mother fucker, motherfuck, motherfucked, motherfucker, motherfuckers, motherfuckin, motherfucking, motherfuckings, motherfuckka, motherfucks, muff, mutha, muthafecker, muthafuckker, muther, mutherfucker, n1gga, n1gger, nazi, nigg3r, nigg4h, nigga, niggah, niggas, niggaz, nigger, niggers , nob, nob jokey, nobhead, nobjocky, nobjokey, numbnuts, nutsack, orgasim , orgasims , orgasm, orgasms , p0rn, pawn, pecker, penis, penisfucker, phonesex, phuck, phuk, phuked, phuking, phukked, phukking, phuks, phuq, pigfucker, pimpis, piss, pissed, pisser, pissers, pisses , pissflaps, pissin , pissing, pissoff , poop, porn, porno, pornography, pornos, prick, pricks , pron, pube, pusse, pussi, pussies, pussy, pussys , rectum, retard, rimjaw, rimming, s hit, s.o.b., sadist, schlong, screwing, scroat, scrote, scrotum, semen, sex, sh!+, sh!t, sh1t, shag, shagger, shaggin, shagging, shemale, shi+, shit, shitdick, shite, shited, shitey, shitfuck, shitfull, shithead, shiting, shitings, shits, shitted, shitter, shitters , shitting, shittings, shitty , skank, slut, sluts, smegma, smut, snatch, son-of-a-bitch, spac, spunk, s_h_i_t, t1tt1e5, t1tties, teets, teez, testical, testicle, tit, titfuck, tits, titt, tittie5, tittiefucker, titties, tittyfuck, tittywank, titwank, tosser, turd, tw4t, twat, twathead, twatty, twunt, twunter, v14gra, v1gra, vagina, viagra, vulva, w00se, wang, wank, wanker, wanky, whoar, whore, willies, xrated, xxx',
            'html_before' => '',
            'html_after' => '',
            'hide_curse' => '',
            'hide_after_fail' => '',
            'hide_after_success' => '',
            'recaptcha_add' => '',
            'recaptcha_site_key' => '',
            'recaptcha_secret_key' => '',
            'recaptcha_theme' => 'Light',
            'recaptcha_language' => 'en',
            'captcha_spam' => 'Please check the ReCaptcha before submitting!',
            'captcha_spam' => 'Please do not spam!',
            'post_excerpt' => '',
            'post_type' => 'post',
            'accept_comments' => 'open',
            'ping_status' => 'open',
            'password' => '',
            'post_format' => 'post-format-standard',
            'extra_info' => 'on',
            'unique_content' => '',
            'default_title' => 'Prometheus Submitted Post',
            'default_tags' => '',
            'default_content' => '',
            'default_type' => 'post',
            'default_category' => '',
            'default_excerpt' => '',
            'default_comment' => 'open',
            'default_format' => 'post-format-standard',
            'default_password' => '',
            'default_ping' => 'open',
            'multiple_categories' => '',
            'allow_names' => '',
            'save_failed_submit' => '',
            'user_categories' => '5',
            'max_chars_other' => '',
            'min_chars_other' => '',
            'max_chars_content' => '',
            'min_chars_content' => '',
            'max_chars_title' => '',
            'min_chars_title' => '',
            'enabled_categories' => $all_cats,
            'auto_categories' => array(),
            'auto_tags' => '',
            'more_files' => '',
            'max_files' => '',
            'max_file_size' => '',
            'min_file_size' => '',
            'min_files' => '',
            'allowed_extension' => '',
            'max_width' => '',
            'min_width' => '',
            'max_height' => '',
            'min_height' => '',
            'admin_notice' => '',
            'max_urls' => '',
            'allow_html' => '',
            'add_media' => '',
            'allow_drag' => '',
            'auto_include' => '',
            'insert_only_images' => '',
            'link_images' => '',
            'featured_image' => '',
            'image_height' => '',
            'image_width' => '',
            'sender_email_address' => '',
            'email_content' => 'Check out the new user post on your blog!',
            'email_subject' => '[Prometheus] A new post just got submitted to your website!',
            'wrap_fieldset' => '',
            'bot_trap' => 'Please Leave This Field Empty. This is a trap for Spam Bots.',
            'form_theme' => 'theme',
            'form_color' => '#ffffff',
            'fieldset_color' => '#ffffff',
            'fieldset_border' => '#ffffff',
            'border_width' => '0',
            'form_border' => '#ffffff',
            'form_border_width' => '0',
            'font_type' => 'Arial,Arial,Helvetica,sans-serif',
            'font_size' => '10',
            'font_color' => '#000000',
            'bold_fonts' => '',
            'italic_fonts' => '',
            'underline_fonts' => '',
            'form_transparent' => '',
            'fieldset_transparent' => '',
            'custom_css' => 'div#prometheus-div fieldset {border: 5px solid #1F497D; background: #ddd; border-radius: 5px; padding: 15px; margin: 0 10px; } div#prometheus-div fieldset legend {background: #1F497D; color: #fff; padding: 5px 10px ; font-size: 32px; border-radius: 5px; box-shadow: 0 0 0 5px #ddd; margin-left: 20px; } div#prometheus-div input { width:100%; } div#prometheus-div select {width:100%; }'
        );
        if($default)
        {
            update_option('prometheus_Main_Settings', $prometheus_Main_Settings);
        }
        else
        {
            add_option('prometheus_Main_Settings', $prometheus_Main_Settings);
        }
    }
    if (!get_option('prometheus_Form_Settings') || $default) {
        $prometheus_Main_Settings = get_option('prometheus_Main_Settings', false);
        $prometheus_Form_Settings = array(
            'user_name' => 'Your Name',
            'user_email' => 'Your Email',
            'user_url' => 'Your Site Name',
            'post_title' => 'Post Title',
            'post_tags' => 'Post Tags',
            'post_password' => 'Post Password',
            'post_excerpt' => 'Post Excerpt',
            'post_category' => 'Post Category',
            'accept_comments' => 'Accept Comments',
            'accept_pings' => 'Accept Pings',
            'post_format' => 'Post Format',
            'post_or_page' => 'Post or Page',
            'post_attachment' => 'Post Attachment',
            'post_content' => 'Post Content',
            'submit_button' => 'Submit Post',
            'bot_trap' => 'Please Leave This Field Empty. This is a trap for Spam Bots',
            'duplicate' => 'Duplicate post titles are not allowed!',
            'duplicate2' => 'Duplicate post content is not allowed!',
            'failed' => 'Failed to insert your post into WordPress, try again later!',
            'captcha' => 'The Captcha verification string you entered is incorrect!',
            'bot' => 'You entered text in a hidden textfield that functions as a honeypot bot trap!',
            'banned' => 'Sorry but you are banned from sending further posts!',
            'user' => 'You are required to enter a user name!',
            'email' => 'You are required to enter an email address!',
            'url' => 'You are required to enter the URL of your website!',
            'title' => 'You are required to enter a title for the submitted post!',
            'tags' => 'You are required to enter tags for the submitted post!',
            'category' => 'You are required to enter a category for the submitted post!',
            'content' => 'You are required to enter content for the submitted post!',
            'reqcaptcha' => 'You are required to enter the required captcha for the submitted post!',
            'excerpt' => 'You are required to enter an excerpt for the submitted post!',
            'comments' => 'You are required to specify if you want to enable comments for your submitted post!',
            'ping' => 'You are required to specify if you want to pings for your submitted post!',
            'password' => 'You are required to set a password for your submitted post!',
            'format' => 'You are required to choose a format for your submitted post!',
            'type' => 'You are required to choose the type for your submitted post (post or page)!',
            'image' => 'You are required to add an image for your submitted post!',
            'notallowed' => 'You are not allowed to submit posts (you are not on the "allowed list")!',
            'nopriviledges' => 'You do not have enough priviledges to submit your post in this form!',
            'titlelong' => 'The title is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_title'] . ' characters.',
            'titleshort' => 'The title is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_title'] . ' characters.',
            'contentlong' => 'The content is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_content'] . ' characters.',
            'contentshort' => 'The content is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_content'] . ' characters.',
            'authorlong' => 'The author name is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_other'] . ' characters.',
            'authorshort' => 'The author name is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_other'] . ' characters.',
            'emaillong' => 'The email is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_other'] . ' characters.',
            'emailshort' => 'The email is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_other'] . ' characters.',
            'urllong' => 'The author url is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_other'] . ' characters.',
            'urlshort' => 'The author url is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_other'] . ' characters.',
            'tagslong' => 'The tags string is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_other'] . ' characters.',
            'tagsshort' => 'The tags string is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_other'] . ' characters.',
            'excerptlong' => 'The excerpt is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_other'] . ' characters.',
            'excerptshort' => 'The excerpt is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_other'] . ' characters.',
            'passwordlong' => 'The password is too long! Keep it under ' . $prometheus_Main_Settings['max_chars_other'] . ' characters.',
            'passwordshort' => 'The password is too short! Keep it above ' . $prometheus_Main_Settings['min_chars_other'] . ' characters.',
            'maxfiles' => 'Maximum number of uploaded files exceeded! Maximum file size is ' . $prometheus_Main_Settings['max_files'] . ' file(s).',
            'maxsize' => 'Maximum file size exceeded! Maximum is ' . $prometheus_Main_Settings['max_file_size'] . ' bytes.',
            'minsize' => 'Submitted file is below the minimum file size allowed! Minimum file size is ' . $prometheus_Main_Settings['min_file_size'] . ' bytes.',
            'minfiles' => 'Minimum file upload count not met! You must upload at least ' . $prometheus_Main_Settings['min_files'] . ' file(s).',
            'notallowedextension' => 'Submitted File Extension Not Allowed. Allowed Extensions are: ' . $prometheus_Main_Settings['allowed_extension'],
            'maxheight' => 'Maximum image height exceeded. Maximum is: ' . $prometheus_Main_Settings['max_height'] . 'px',
            'minheight' => 'Minimum image height not met. Minimum is: ' . $prometheus_Main_Settings['min_height'] . 'px',
            'maxwidth' => 'Maximum image width exceeded. Maximum is: ' . $prometheus_Main_Settings['max_width'] . 'px',
            'minwidth' => 'Minimum image width not met. Minimum is: ' . $prometheus_Main_Settings['min_width'] . 'px',
            'maxurls' => 'Maximum number of URLs exceeded in post content. Maximum is: ' . $prometheus_Main_Settings['max_urls'],
            'unknown' => 'Unknown Error!',
            'error_string' => 'Error: ',
            'category_default' => 'Please select a category...',
            'accept_string' => 'Accept',
            'deny_string' => 'Deny',
            'is_post' => 'Post',
            'is_page' => 'Page',
            'is_standard' => 'Standard',
            'is_aside' => 'Aside',
            'is_gallery' => 'Gallery',
            'is_link' => 'Link',
            'is_image' => 'Image',
            'is_quote' => 'Quote',
            'is_status' => 'Status',
            'is_video' => 'Video',
            'is_audio' => 'Audio',
            'is_chat' => 'Chat',
            'submit_post' => 'Submit Post',
            'success_string' => 'Your post was sent! Thank You!'
        );
        if($default)
        {
            update_option('prometheus_Form_Settings', $prometheus_Form_Settings);
        }
        else
        {
            add_option('prometheus_Form_Settings', $prometheus_Form_Settings);
        }
    }
}

register_activation_hook(__FILE__, 'prometheus_check_version');
function prometheus_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.3';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
}

add_action('admin_init', 'prometheus_register_mysettings');
function prometheus_register_mysettings()
{
    register_setting('prometheus_option_group', 'prometheus_Main_Settings');
    register_setting('prometheus_option_group2', 'prometheus_Form_Settings');
    if(is_multisite())
    {
        if (!get_option('prometheus_Main_Settings'))
        {
            prometheus_activation_callback(TRUE);
        }
    }
    //admin notice
    $prometheus_Main_Settings = get_option('prometheus_Main_Settings', false);
    if (isset($prometheus_Main_Settings['admin_notice']) && $prometheus_Main_Settings['admin_notice'] === 'on') {
        add_action('admin_notices', 'prometheus_admin_notices');
    }
}
function prometheus_admin_notices()
{
    //get all posts that are not published
    $query     = array(
        'post_status' => array(
            'pending',
            'draft',
            'auto-draft',
            'future'
        ),
        'post_type' => array(
            'post'
        )
    );
    $found     = 0;
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        if (get_post_meta($post->ID, 'prometheus_submitted_post', true) == 'true') {
            $found = 1;
        }
    }
    if ($found == 1) {
?>
   <div class="notice notice-info is-dismissible">
      <p><b>[Prometheus User Submitted Content]</b> New posts are <a href="<?php
        echo admin_url() . 'edit.php';
?>"><b>awaiting moderation</b></a>!</p>
   </div>
<?php
    }
    //get all pages that are not published
    $query     = array(
        'post_status' => array(
            'pending',
            'draft',
            'auto-draft',
            'future'
        ),
        'post_type' => array(
            'page'
        )
    );
    $found     = 0;
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        if (get_post_meta($post->ID, 'prometheus_submitted_post', true) == 'true') {
            $found = 1;
        }
    }
    if ($found == 1) {
?>
   <div class="notice notice-info is-dismissible">
      <p>New pages are <a href="<?php
        echo admin_url() . 'edit.php?post_type=page';
?>">awaiting moderation</a>!</p>
   </div>
<?php
    }
}
function prometheus_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function prometheus_get_file_url($url)
{
    return prometheus_get_plugin_url() . '/' . $url;
}

add_shortcode('prometheus_list_submitted_posts', 'prometheus_list_submitted_posts');
function prometheus_list_submitted_posts()
{
    $nr        = 0;
    $ech       = '<ul>';
    $query     = array(
        'post_status' => array(
            'publish',
            'pending',
            'draft',
            'auto-draft',
            'future',
            'private',
            'inherit',
            'trash'
        ),
        'post_type' => array(
            'post'
        )
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        if (get_post_meta($post->ID, 'prometheus_submitted_post', true) == 'true') {
            $ech .= '<li><a href="' . get_permalink($post->ID) . '">' . $post->post_title . '</a></li>';
            $nr++;
        }
    }
    if ($nr == 0) {
        $ech .= '<li>No posts submitted!</li>';
    }
    $ech .= '</ul>';
    return $ech;
}
add_shortcode('prometheus_list_submitted_posts', 'prometheus_list_submitted_pages');
function prometheus_list_submitted_pages()
{
    $nr        = 0;
    $ech       = '<ul>';
    $query     = array(
        'post_status' => array(
            'publish',
            'pending',
            'draft',
            'auto-draft',
            'future',
            'private',
            'inherit',
            'trash'
        ),
        'post_type' => array(
            'page'
        )
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        if (get_post_meta($post->ID, 'prometheus_submitted_post', true) == 'true') {
            $ech .= '<li><a href="' . get_permalink($post->ID) . '">' . $post->post_title . '</a></li>';
            $nr++;
        }
    }
    if ($nr == 0) {
        $ech .= '<li>No pages submitted!</li>';
    }
    $ech .= '</ul>';
    return $ech;
}
add_shortcode('prometheus_list_submitted_posts', 'prometheus_list_submitted_posts_and_pages');
function prometheus_list_submitted_posts_and_pages()
{
    $nr        = 0;
    $ech       = '<ul>';
    $query     = array(
        'post_status' => array(
            'publish',
            'pending',
            'draft',
            'auto-draft',
            'future',
            'private',
            'inherit',
            'trash'
        ),
        'post_type' => array(
            'post',
            'page'
        )
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        if (get_post_meta($post->ID, 'prometheus_submitted_post', true) == 'true') {
            $ech .= '<li><a href="' . get_permalink($post->ID) . '">' . $post->post_title . '</a></li>';
            $nr++;
        }
    }
    if ($nr == 0) {
        $ech .= '<li>No posts or pages submitted!</li>';
    }
    $ech .= '</ul>';
    return $ech;
}
add_shortcode('prometheus_add_form', 'prometheus_add_form');
function prometheus_add_form($atts)
{
    $prometheus_Main_Settings = get_option('prometheus_Main_Settings', false);
    
    if (isset($prometheus_Main_Settings['prometheus_enabled']) && $prometheus_Main_Settings['prometheus_enabled'] === 'on') {
        if (isset($prometheus_Main_Settings['need_login']) && $prometheus_Main_Settings['need_login'] === 'on' && !is_user_logged_in()) {
            if (isset($prometheus_Main_Settings['need_login_message'])) {
                return $prometheus_Main_Settings['need_login_message'];
            } else {
                return "You need to be logged in to submit your posts!";
            }
        } else {
            if (isset($_GET['hidden']) && !empty($_GET['hidden'])) {
                return "";
            }
            
            $prometheus_Form_Settings = get_option('prometheus_Form_Settings', false);
            
            $ech = '<div id="prometheus-div">';
            if (isset($prometheus_Main_Settings['html_before']) && $prometheus_Main_Settings['html_before'] != '') {
                $ech .= $prometheus_Main_Settings['html_before'];
            }
            if (isset($prometheus_Main_Settings['form_theme']) && $prometheus_Main_Settings['form_theme'] == 'custom') {
                $ech .= '<style>div#prometheus-div label{font-family: ' . $prometheus_Main_Settings['font_type'] . ' !important;}div#prometheus-div form{color:' . $prometheus_Main_Settings['font_color'] . ' !important;';
                if (isset($prometheus_Main_Settings['bold_fonts']) && $prometheus_Main_Settings['bold_fonts'] == 'on') {
                    $ech .= 'font-weight: bold;';
                }
                if (isset($prometheus_Main_Settings['underline_fonts']) && $prometheus_Main_Settings['underline_fonts'] == 'on') {
                    $ech .= 'text-decoration: underline;';
                }
                if (isset($prometheus_Main_Settings['italic_fonts']) && $prometheus_Main_Settings['italic_fonts'] == 'on') {
                    $ech .= 'font-style: italic;';
                }
                $ech .= 'font-size:' . $prometheus_Main_Settings['font_size'] . 'px !important;font-family: "' . $prometheus_Main_Settings['font_type'] . '" !important;border-style:solid;border-width:' . $prometheus_Main_Settings['form_border_width'] . 'px;border-color:' . $prometheus_Main_Settings['form_border'] . ';}div#prometheus-div fieldset{color:' . $prometheus_Main_Settings['font_color'] . ' !important;';
                if (isset($prometheus_Main_Settings['bold_fonts']) && $prometheus_Main_Settings['bold_fonts'] == 'on') {
                    $ech .= 'font-weight: bold;';
                }
                if (isset($prometheus_Main_Settings['underline_fonts']) && $prometheus_Main_Settings['underline_fonts'] == 'on') {
                    $ech .= 'text-decoration: underline;';
                }
                if (isset($prometheus_Main_Settings['italic_fonts']) && $prometheus_Main_Settings['italic_fonts'] == 'on') {
                    $ech .= 'font-style: italic;';
                }
                $ech .= 'font-size:' . $prometheus_Main_Settings['font_size'] . 'px !important;font-family: "' . $prometheus_Main_Settings['font_type'] . '" !important;border-style:solid;border-width:' . $prometheus_Main_Settings['border_width'] . 'px;border-color:' . $prometheus_Main_Settings['fieldset_border'] . ';';
                if (isset($prometheus_Main_Settings['fieldset_transparent']) && $prometheus_Main_Settings['fieldset_transparent'] == 'on') {
                    $ech .= 'background-color:transparent;}</style>';
                } else {
                    $ech .= 'background-color:' . $prometheus_Main_Settings['fieldset_color'] . ';}</style>';
                }
            } elseif ($prometheus_Main_Settings['form_theme'] == 'own') {
                if (isset($prometheus_Main_Settings['custom_css']) && $prometheus_Main_Settings['custom_css'] != '') {
                    $ech .= '<style>' . $prometheus_Main_Settings['custom_css'] . '</style>';
                }
            }
            $ech .= '<form ';
            if (isset($prometheus_Main_Settings['form_transparent']) && $prometheus_Main_Settings['form_transparent'] == 'on') {
                $ech .= 'style="background-color:transparent;" ';
            } else {
                if (isset($prometheus_Main_Settings['form_theme']) && $prometheus_Main_Settings['form_theme'] == 'custom') {
                    $ech .= 'style="background-color:' . $prometheus_Main_Settings['form_color'] . ';" ';
                }
            }
            $ech .= 'id="prometheus_form" method="post" enctype="multipart/form-data"';
            $ech .= 'action="">';
            if (isset($_GET['prometheus-error']) && !empty($_GET['prometheus-error'])) {
                if (isset($prometheus_Main_Settings['failed_message']) && $prometheus_Main_Settings['failed_message'] != '') {
                    $ech .= "<div>" . $prometheus_Main_Settings['failed_message'] . "</div>";
                } else {
                    $prometheus_error = sanitize_text_field($_GET['prometheus-error']);
                    $error_str        = '';
                    if ($prometheus_error == 'duplicate') {
                        $error_str .= $prometheus_Form_Settings['duplicate'];
                    } elseif ($prometheus_error == 'duplicate2') {
                        $error_str .= $prometheus_Form_Settings['duplicate2'];
                    } elseif ($prometheus_error == 'failed') {
                        $error_str .= $prometheus_Form_Settings['failed'];
                    } elseif ($prometheus_error == 'captcha') {
                        $error_str .= $prometheus_Form_Settings['captcha'];
                    } elseif ($prometheus_error == 'bot') {
                        $error_str .= $prometheus_Form_Settings['bot'];
                    } elseif ($prometheus_error == 'banned') {
                        $error_str .= $prometheus_Form_Settings['banned'];
                    } elseif ($prometheus_error == 'user') {
                        $error_str .= $prometheus_Form_Settings['user'];
                    } elseif ($prometheus_error == 'email') {
                        $error_str .= $prometheus_Form_Settings['email'];
                    } elseif ($prometheus_error == 'url') {
                        $error_str .= $prometheus_Form_Settings['url'];
                    } elseif ($prometheus_error == 'title') {
                        $error_str .= $prometheus_Form_Settings['title'];
                    } elseif ($prometheus_error == 'tags') {
                        $error_str .= $prometheus_Form_Settings['tags'];
                    } elseif ($prometheus_error == 'category') {
                        $error_str .= $prometheus_Form_Settings['category'];
                    } elseif ($prometheus_error == 'content') {
                        $error_str .= $prometheus_Form_Settings['content'];
                    } elseif ($prometheus_error == 'reqcaptcha') {
                        $error_str .= $prometheus_Form_Settings['reqcaptcha'];
                    } elseif ($prometheus_error == 'excerpt') {
                        $error_str .= $prometheus_Form_Settings['excerpt'];
                    } elseif ($prometheus_error == 'comments') {
                        $error_str .= $prometheus_Form_Settings['comments'];
                    } elseif ($prometheus_error == 'ping') {
                        $error_str .= $prometheus_Form_Settings['ping'];
                    } elseif ($prometheus_error == 'password') {
                        $error_str .= $prometheus_Form_Settings['password'];
                    } elseif ($prometheus_error == 'format') {
                        $error_str .= $prometheus_Form_Settings['format'];
                    } elseif ($prometheus_error == 'type') {
                        $error_str .= $prometheus_Form_Settings['type'];
                    } elseif ($prometheus_error == 'image') {
                        $error_str .= $prometheus_Form_Settings['image'];
                    } elseif ($prometheus_error == 'notallowed') {
                        $error_str .= $prometheus_Form_Settings['notallowed'];
                    } elseif ($prometheus_error == 'nopriviledges') {
                        $error_str .= $prometheus_Form_Settings['nopriviledges'];
                    } elseif ($prometheus_error == 'titlelong') {
                        $error_str .= $prometheus_Form_Settings['titlelong'];
                    } elseif ($prometheus_error == 'titleshort') {
                        $error_str .= $prometheus_Form_Settings['titleshort'];
                    } elseif ($prometheus_error == 'contentlong') {
                        $error_str .= $prometheus_Form_Settings['contentlong'];
                    } elseif ($prometheus_error == 'contentshort') {
                        $error_str .= $prometheus_Form_Settings['contentshort'];
                    } elseif ($prometheus_error == 'authorlong') {
                        $error_str .= $prometheus_Form_Settings['authorlong'];
                    } elseif ($prometheus_error == 'authorshort') {
                        $error_str .= $prometheus_Form_Settings['authorshort'];
                    } elseif ($prometheus_error == 'emaillong') {
                        $error_str .= $prometheus_Form_Settings['emaillong'];
                    } elseif ($prometheus_error == 'emailshort') {
                        $error_str .= $prometheus_Form_Settings['emailshort'];
                    } elseif ($prometheus_error == 'urllong') {
                        $error_str .= $prometheus_Form_Settings['urllong'];
                    } elseif ($prometheus_error == 'urlshort') {
                        $error_str .= $prometheus_Form_Settings['urlshort'];
                    } elseif ($prometheus_error == 'tagslong') {
                        $error_str .= $prometheus_Form_Settings['tagslong'];
                    } elseif ($prometheus_error == 'tagsshort') {
                        $error_str .= $prometheus_Form_Settings['tagsshort'];
                    } elseif ($prometheus_error == 'excerptlong') {
                        $error_str .= $prometheus_Form_Settings['excerptlong'];
                    } elseif ($prometheus_error == 'excerptshort') {
                        $error_str .= $prometheus_Form_Settings['excerptshort'];
                    } elseif ($prometheus_error == 'passwordlong') {
                        $error_str .= $prometheus_Form_Settings['passwordlong'];
                    } elseif ($prometheus_error == 'passwordshort') {
                        $error_str .= $prometheus_Form_Settings['passwordshort'];
                    } elseif ($prometheus_error == 'maxfiles') {
                        $error_str .= $prometheus_Form_Settings['maxfiles'];
                    } elseif ($prometheus_error == 'maxsize') {
                        $error_str .= $prometheus_Form_Settings['maxsize'];
                    } elseif ($prometheus_error == 'minsize') {
                        $error_str .= $prometheus_Form_Settings['minsize'];
                    } elseif ($prometheus_error == 'minfiles') {
                        $error_str .= $prometheus_Form_Settings['minfiles'];
                    } elseif ($prometheus_error == 'notallowedextension') {
                        $error_str .= $prometheus_Form_Settings['notallowedextension'];
                    } elseif ($prometheus_error == 'maxheight') {
                        $error_str .= $prometheus_Form_Settings['maxheight'];
                    } elseif ($prometheus_error == 'minheight') {
                        $error_str .= $prometheus_Form_Settings['minheight'];
                    } elseif ($prometheus_error == 'maxwidth') {
                        $error_str .= $prometheus_Form_Settings['maxwidth'];
                    } elseif ($prometheus_error == 'minwidth') {
                        $error_str .= $prometheus_Form_Settings['minwidth'];
                    } elseif ($prometheus_error == 'maxurls') {
                        $error_str .= $prometheus_Form_Settings['maxurls'];
                    } else {
                        $error_str .= $prometheus_Form_Settings['unknown'];
                    }
                    $ech .= "<div>" . $prometheus_Form_Settings['error_string'] . $error_str . "</div>";
                }
            }
            if (isset($_GET['prometheus-success']) && !empty($_GET['prometheus-success'])) {
                if (isset($prometheus_Main_Settings['success_message']) && $prometheus_Main_Settings['success_message'] != '') {
                    $ech .= "<div>" . $prometheus_Main_Settings['success_message'] . "</div>";
                } else {
                    $ech .= "<div>" . $prometheus_Form_Settings['success_string'] . "</div>";
                }
            }
            if ($prometheus_Main_Settings['user_name'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="user_name">' . $prometheus_Form_Settings['user_name'];
                if ($prometheus_Main_Settings['user_name'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="user_name" name="user_name" type="text" value="';
                if (isset($_GET['user_name'])) {
                    $ech .= $_GET['user_name'];
                }
                $ech .= '" placeholder="' . $prometheus_Form_Settings['user_name'] . '"';
                if ($prometheus_Main_Settings['user_name'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['user_email'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="user_email">' . $prometheus_Form_Settings['user_email'];
                if ($prometheus_Main_Settings['user_email'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="user_email" name="user_email" type="email" value="';
                if (isset($_GET['user_email'])) {
                    $ech .= $_GET['user_email'];
                }
                $ech .= '" placeholder="' . $prometheus_Form_Settings['user_email'] . '" ';
                if ($prometheus_Main_Settings['user_email'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['user_url'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="user_url">' . $prometheus_Form_Settings['user_url'];
                if ($prometheus_Main_Settings['user_url'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="user_url" name="user_url" type="url" validator="url" value="';
                if (isset($_GET['user_url'])) {
                    $ech .= $_GET['user_url'];
                }
                $ech .= '" placeholder="' . $prometheus_Form_Settings['user_url'] . '" ';
                if ($prometheus_Main_Settings['user_url'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_title'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_title">' . $prometheus_Form_Settings['post_title'];
                if ($prometheus_Main_Settings['post_title'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="post_title" name="post_title" type="text" value="';
                if (isset($_GET['post_title'])) {
                    $ech .= $_GET['post_title'];
                }
                $ech .= '" placeholder="' . $prometheus_Form_Settings['post_title'] . '" ';
                if ($prometheus_Main_Settings['post_title'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_tags'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_tags">' . $prometheus_Form_Settings['post_tags'];
                if ($prometheus_Main_Settings['post_tags'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="post_tags" name="post_tags" type="text" value="';
                if (isset($_GET['post_tags'])) {
                    $ech .= $_GET['post_tags'];
                }
                $ech .= '" placeholder="' . $prometheus_Form_Settings['post_tags'] . '" ';
                if ($prometheus_Main_Settings['post_tags'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_category'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_category">' . $prometheus_Form_Settings['post_category'];
                if ($prometheus_Main_Settings['post_category'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<select id="post_category" name="post_category[]"';
                
                if (isset($prometheus_Main_Settings['multiple_categories']) && $prometheus_Main_Settings['multiple_categories'] === 'on') {
                    $ech .= ' multiple';
                }
                if ($prometheus_Main_Settings['post_category'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '"><option value="" disabled selected>' . $prometheus_Form_Settings['category_default'] . '</option>';
                foreach ($prometheus_Main_Settings['enabled_categories'] as $category) {
                    $ech .= '<option value="' . $category . '">' . sanitize_text_field(get_cat_name($category)) . '</option>';
                }
                
                $ech .= '</select>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_excerpt'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_excerpt">' . $prometheus_Form_Settings['post_excerpt'];
                if ($prometheus_Main_Settings['post_excerpt'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="post_excerpt" name="post_excerpt" type="text" value="';
                if (isset($_GET['post_excerpt'])) {
                    $ech .= $_GET['post_excerpt'];
                }
                $ech .= '" placeholder="' . $prometheus_Form_Settings['post_excerpt'] . '" ';
                if ($prometheus_Main_Settings['post_excerpt'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_captcha'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_captcha">' . $prometheus_Main_Settings['captcha_question'];
                if ($prometheus_Main_Settings['post_captcha'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="post_captcha" name="post_captcha" type="text" value="" placeholder="' . $prometheus_Main_Settings['captcha_question'] . '" ';
                if ($prometheus_Main_Settings['post_captcha'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['password'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="password">' . $prometheus_Form_Settings['post_password'];
                if ($prometheus_Main_Settings['password'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="password" name="password" type="text" value="" ';
                $ech .= '" placeholder="' . $prometheus_Form_Settings['post_password'] . '" ';
                if ($prometheus_Main_Settings['password'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['accept_comments'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="accept_comments">' . $prometheus_Form_Settings['accept_comments'];
                if ($prometheus_Main_Settings['accept_comments'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<select id="accept_comments" name="accept_comments"';
                if ($prometheus_Main_Settings['accept_comments'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '"><option value="open" selected>' . $prometheus_Form_Settings['accept_string'] . '</option><option value="closed">' . $prometheus_Form_Settings['deny_string'] . '</option></select>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['ping_status'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="ping_status">' . $prometheus_Form_Settings['accept_pings'];
                if ($prometheus_Main_Settings['ping_status'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<select id="ping_status" name="ping_status"';
                if ($prometheus_Main_Settings['ping_status'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '"><option value="open" selected>' . $prometheus_Form_Settings['accept_string'] . '</option><option value="closed">' . $prometheus_Form_Settings['deny_string'] . '</option></select>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_format'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_format">' . $prometheus_Form_Settings['post_format'];
                if ($prometheus_Main_Settings['post_format'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<select id="post_format" name="post_format"';
                if ($prometheus_Main_Settings['post_format'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '"><option value="post-format-standard" selected>' . $prometheus_Form_Settings['is_standard'] . '</option><option value="post-format-aside">' . $prometheus_Form_Settings['is_aside'] . '</option><option value="post-format-gallery">' . $prometheus_Form_Settings['is_gallery'] . '</option><option value="post-format-link">' . $prometheus_Form_Settings['is_link'] . '</option><option value="post-format-image">' . $prometheus_Form_Settings['is_image'] . '</option><option value="post-format-quote">' . $prometheus_Form_Settings['is_quote'] . '</option><option value="post-format-status">' . $prometheus_Form_Settings['is_status'] . '</option><option value="post-format-video">' . $prometheus_Form_Settings['is_video'] . '</option><option value="post-format-audio">' . $prometheus_Form_Settings['is_audio'] . '</option><option value="post-format-chat">' . $prometheus_Form_Settings['is_chat'] . '</option></select>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_type'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_type">' . $prometheus_Form_Settings['post_or_page'];
                if ($prometheus_Main_Settings['post_type'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<select id="post_type" name="post_type"';
                if ($prometheus_Main_Settings['post_type'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '"><option value="post" selected>' . $prometheus_Form_Settings['is_post'] . '</option><option value="page">' . $prometheus_Form_Settings['is_page'] . '</option></select>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_image'] != 'Hide') {
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<label for="post_image">' . $prometheus_Form_Settings['post_attachment'];
                if ($prometheus_Main_Settings['post_image'] == 'ShowRequire') {
                    $ech .= '*';
                }
                $ech .= '</label>&nbsp;<input id="post_image" name="post_image[]" type="file" ';
                if (isset($prometheus_Main_Settings['allowed_extension']) && $prometheus_Main_Settings['allowed_extension'] != '') {
                    $ech .= 'accept="';
                    $exten = explode(",", $prometheus_Main_Settings['allowed_extension']);
                    if (isset($exten[0])) {
                        $ech .= '.' . trim($exten[0]);
                        array_shift($exten);
                    }
                    foreach ($exten as $extt) {
                        $ech .= ', .' . trim($extt);
                    }
                    $ech .= '" ';
                }
                if (isset($prometheus_Main_Settings['more_files']) && $prometheus_Main_Settings['more_files'] === 'on') {
                    $ech .= 'multiple ';
                }
                $ech .= 'value="" ';
                if ($prometheus_Main_Settings['post_image'] == 'ShowRequire') {
                    $ech .= ' required';
                }
                $ech .= '>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if ($prometheus_Main_Settings['post_content'] != 'Hide') {
                if (isset($prometheus_Main_Settings['rich_editor']) && $prometheus_Main_Settings['rich_editor'] === 'on') {
                    if (isset($prometheus_Main_Settings['add_media']) && $prometheus_Main_Settings['add_media'] === 'on') {
                        $add_media = true;
                    } else {
                        $add_media = false;
                    }
                    if (isset($prometheus_Main_Settings['allow_drag']) && $prometheus_Main_Settings['allow_drag'] === 'on') {
                        $allow_drag = true;
                    } else {
                        $allow_drag = false;
                    }
                    if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                        $ech .= '<fieldset>';
                    }
                    $ech .= '<label for="post_content">' . $prometheus_Form_Settings['post_content'];
                    if ($prometheus_Main_Settings['post_content'] == 'ShowRequire') {
                        $ech .= '*';
                    }
                    $ech .= '</label>&nbsp;<div class="prometheus_rich_editor">';
                    $pro_rte_settings = array(
                        'wpautop' => true,
                        'media_buttons' => $add_media,
                        'textarea_name' => 'post_content',
                        'textarea_rows' => '12',
                        'tabindex' => '',
                        'editor_css' => '',
                        'editor_class' => 'prometheus_rich_content',
                        'teeny' => false,
                        'dfw' => false,
                        'tinymce' => true,
                        'quicktags' => true,
                        'drag_drop_upload' => $allow_drag
                    );
                    $initial          = '';
                    if (isset($_GET['post_content'])) {
                        $initial = $_GET['post_content'];
                    }
                    ob_start();
                    wp_editor($initial, 'prometheus_rich_form', $pro_rte_settings);
                    $ech .= ob_get_clean();
                    $ech .= '</div>';
                    if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                        $ech .= '</fieldset>';
                    } else {
                        $ech .= '<br/><br/>';
                    }
                } else {
                    if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                        $ech .= '<fieldset>';
                    }
                    $ech .= '<label for="post_content">' . $prometheus_Form_Settings['post_content'];
                    if ($prometheus_Main_Settings['post_content'] == 'ShowRequire') {
                        $ech .= '*';
                    }
                    $ech .= '</label>&nbsp;<textarea rows="5" id="post_content" name="post_content" value="';
                    if (isset($_GET['post_content'])) {
                        $ech .= $_GET['post_content'];
                    }
                    $ech .= '" placeholder="' . $prometheus_Form_Settings['post_content'] . '" ';
                    if ($prometheus_Main_Settings['post_content'] == 'ShowRequire') {
                        $ech .= ' required';
                    }
                    $ech .= '></textarea>';
                    if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                        $ech .= '</fieldset>';
                    } else {
                        $ech .= '<br/><br/>';
                    }
                }
            }
            if (isset($prometheus_Main_Settings['recaptcha_add']) && $prometheus_Main_Settings['recaptcha_add'] === 'on' && isset($prometheus_Main_Settings['recaptcha_site_key']) && $prometheus_Main_Settings['recaptcha_site_key'] != '' && isset($prometheus_Main_Settings['recaptcha_secret_key']) && $prometheus_Main_Settings['recaptcha_secret_key'] != '') {
                wp_enqueue_script('prometheus-recaptcha', 'https://www.google.com/recaptcha/api.js?hl=' . $prometheus_Main_Settings['recaptcha_language'], array(), '1.0.0', true);
                wp_enqueue_script('prometheus_enque_script', prometheus_get_file_url('res/recaptcha.js'), array(
                    'jquery'
                ), '1.0.0', true);
                $settings = array(
                    'url_to_php' => prometheus_get_file_url('res/prometheus_google_captcha.php'),
                    'secret' => $prometheus_Main_Settings['recaptcha_secret_key'],
                    'incorrect' => $prometheus_Main_Settings['captcha_incorrect'],
                    'spam' => $prometheus_Main_Settings['captcha_spam']
                );
                wp_localize_script('prometheus_enque_script', 'settings', $settings);
                $key   = $prometheus_Main_Settings['recaptcha_site_key'];
                $theme = $prometheus_Main_Settings['recaptcha_theme'];
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '<fieldset>';
                }
                $ech .= '<div class="g-recaptcha" data-sitekey="' . $key . '" data-theme="' . $theme . '" style="transform:scale(0.90);-webkit-transform:scale(0.90);transform-origin:0 0;-webkit-transform-origin:0 0;"></div>';
                if (isset($prometheus_Main_Settings['wrap_fieldset']) && $prometheus_Main_Settings['wrap_fieldset'] == 'on') {
                    $ech .= '</fieldset>';
                } else {
                    $ech .= '<br/><br/>';
                }
            }
            if (isset($prometheus_Main_Settings['spam_protect']) && $prometheus_Main_Settings['spam_protect'] === 'on') {
                $ech .= '<fieldset style="display:none;"><label for="user_verify">' . $prometheus_Form_Settings['bot_trap'] . '</label><input id="user_verify" name="user_verify" type="text" value=""></fieldset>';
            }
            $ech .= '<div style="text-align:center;"><input type="submit" id="prometheus-submit-post" name="prometheus-submit-post" value="' . $prometheus_Form_Settings['submit_post'] . '"></div>';
            $ech .= wp_nonce_field('prometheus-nonce', 'prometheus-nonce', false, false);
            $ech .= '<br/></form>';
            if (isset($prometheus_Main_Settings['html_after']) && $prometheus_Main_Settings['html_after'] != '') {
                $ech .= $prometheus_Main_Settings['html_after'];
            }
            $ech .= '</div>';
            return $ech;
        }
    }
    return '';
}

function prometheus_add_meta_box()
{
    
    global $post;
    
    if (get_post_meta($post->ID, 'prometheus_submitted_post', true) == 'true') {
        add_meta_box('prometheus_user_submitted_post', 'Prometheus User Submitted Post Author Information', 'prometheus_meta_box_function', 'post', 'advanced', 'default');
        add_meta_box('prometheus_user_submitted_post', 'Prometheus User Submitted Post Author Information', 'prometheus_meta_box_function', 'page', 'advanced', 'default');
    }
    
}
add_action('add_meta_boxes', 'prometheus_add_meta_box');
function prometheus_meta_box_function($post)
{
    
    $name       = get_post_meta($post->ID, 'author_name', true);
    $email      = get_post_meta($post->ID, 'author_email', true);
    $url        = get_post_meta($post->ID, 'author_url', true);
    $ip         = get_post_meta($post->ID, 'author_ip', true);
    $user_agent = get_post_meta($post->ID, 'author_user_agent', true);
    $referrer   = get_post_meta($post->ID, 'author_referrer', true);
    if (!empty($name) || !empty($email) || !empty($url) || !empty($ip) || !empty($user_agent) || !empty($referrer)) {
        echo '<ul>';
        if (!empty($name))
            echo '<li><b>Author Name:</b> ' . $name . '</li>';
        if (!empty($email))
            echo '<li><b>Author Email:</b> ' . $email . '</li>';
        if (!empty($url))
            echo '<li><b>Author URL:</b> ' . $url . '</li>';
        if (!empty($ip))
            echo '<li><b>Author IP:</b> ' . $ip . '</li>';
        if (!empty($user_agent))
            echo '<li><b>Author User Agent:</b> ' . $user_agent . '</li>';
        if (!empty($referrer))
            echo '<li><b>Author Referrer:</b> ' . $referrer . '</li>';
        echo '</ul>';
    }
}

function prometheus_parse_form()
{
    if (isset($_POST['prometheus-submit-post']) && isset($_POST['prometheus-nonce']) && wp_verify_nonce($_POST['prometheus-nonce'], 'prometheus-nonce') && !empty($_POST['prometheus-submit-post'])) {
        $featured_image           = '';
        $prometheus_Main_Settings = get_option('prometheus_Main_Settings', false);
        if (isset($prometheus_Main_Settings['submit_status'])) {
            $status = $prometheus_Main_Settings['submit_status'];
        } else {
            $status = 'pending';
        }
        if (is_user_logged_in() && isset($prometheus_Main_Settings['need_login']) && $prometheus_Main_Settings['need_login'] == 'on') {
            $user_id = get_current_user_id();
        } else {
            if (isset($prometheus_Main_Settings['anon_users_name'])) {
                if (!is_user_logged_in()) {
                    $user_id = $prometheus_Main_Settings['anon_users_name'];
                } else {
                    $user_id = get_current_user_id();
                }
            } else {
                if (is_user_logged_in()) {
                    $user_id = get_current_user_id();
                } else {
                    $user_id = '1';
                }
            }
        }
        
        $title      = isset($_POST['post_title']) ? sanitize_text_field($_POST['post_title']) : $prometheus_Main_Settings['default_title'];
        $files      = isset($_FILES['post_image']) ? $_FILES['post_image'] : array();
        $user_agent = (isset($_SERVER['HTTP_USER_AGENT']) && isset($prometheus_Main_Settings['extra_info']) && $prometheus_Main_Settings['extra_info'] == 'on') ? $_SERVER['HTTP_USER_AGENT'] : '';
        $referrer   = (isset($_SERVER['HTTP_REFERER']) && isset($prometheus_Main_Settings['extra_info']) && $prometheus_Main_Settings['extra_info'] == 'on') ? $_SERVER['HTTP_REFERER'] : '';
        $ip         = (isset($_SERVER['REMOTE_ADDR']) && isset($prometheus_Main_Settings['extra_info']) && $prometheus_Main_Settings['extra_info'] == 'on') ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
        $author     = isset($_POST['user_name']) ? sanitize_text_field($_POST['user_name']) : '';
        $url        = isset($_POST['user_url']) ? esc_url($_POST['user_url']) : '';
        $email      = isset($_POST['user_email']) ? sanitize_email($_POST['user_email']) : '';
        $tags       = isset($_POST['post_tags']) ? sanitize_text_field($_POST['post_tags']) : $prometheus_Main_Settings['default_tags'];
        $captcha    = isset($_POST['post_captcha']) ? sanitize_text_field($_POST['post_captcha']) : '';
        $verify     = isset($_POST['user_verify']) ? sanitize_text_field($_POST['user_verify']) : '';
        $content    = isset($_POST['post_content']) ? sanitize_text_field($_POST['post_content']) : $prometheus_Main_Settings['default_content'];
        if (isset($prometheus_Main_Settings['allow_html']) && $prometheus_Main_Settings['allow_html'] === 'on') {
            $content = html_entity_decode($content);
        }
        $post_category = '';
        $links         = substr_count($content, "<a href=");
        if (isset($prometheus_Main_Settings['max_urls']) && is_numeric($prometheus_Main_Settings['max_urls']) && $links > intval($prometheus_Main_Settings['max_urls'])) {
            fail_and_redirect('maxurls');
        }
        $counter = 0;
        if ($prometheus_Main_Settings['post_image'] != 'Hide' && count($_FILES['post_image']['name']) > 0) {
            for ($i = 0; $i < count($_FILES['post_image']['name']); $i++) {
                if (isset($prometheus_Main_Settings['max_file_size']) && is_numeric($prometheus_Main_Settings['max_file_size']) && $_FILES['post_image']['size'][$i] > intval($prometheus_Main_Settings['max_file_size'])) {
                    fail_and_redirect('maxsize');
                }
                if (isset($prometheus_Main_Settings['min_file_size']) && is_numeric($prometheus_Main_Settings['min_file_size']) && $_FILES['post_image']['size'][$i] < intval($prometheus_Main_Settings['min_file_size'])) {
                    fail_and_redirect('minsize');
                }
                if (isset($prometheus_Main_Settings['allowed_extension']) && $prometheus_Main_Settings['allowed_extension'] != '') {
                    $allowed   = 0;
                    $filename  = $_FILES['post_image']['name'][$i];
                    $expl      = explode(".", $filename);
                    $extension = end($expl);
                    $exts      = $prometheus_Main_Settings['allowed_extension'];
                    $exts      = explode(",", $exts);
                    foreach ($exts as $ext) {
                        if (trim($ext) == $extension) {
                            $allowed = 1;
                        }
                    }
                    if ($allowed == 0) {
                        fail_and_redirect('notallowedextension');
                    }
                }
                if ($image_info = @getimagesize($_FILES["post_image"]["tmp_name"][$i])) {
                    $is_image = 1;
                    if (isset($image_info[0])) {
                        $image_width = $image_info[0];
                    } else {
                        $image_width = 0;
                    }
                    if (isset($image_info[1])) {
                        $image_height = $image_info[1];
                    } else {
                        $image_height = 0;
                    }
                } else {
                    $is_image     = 0;
                    $image_width  = 0;
                    $image_height = 0;
                }
                if (isset($prometheus_Main_Settings['max_height']) && $prometheus_Main_Settings['max_height'] != '' && is_numeric($prometheus_Main_Settings['max_height'])) {
                    if (intval($image_height) != 0 && intval($image_height) > intval($prometheus_Main_Settings['max_height'])) {
                        fail_and_redirect('maxheight');
                    }
                }
                if (isset($prometheus_Main_Settings['min_height']) && $prometheus_Main_Settings['min_height'] != '' && is_numeric($prometheus_Main_Settings['min_height'])) {
                    if (intval($image_height) != 0 && intval($image_height) < intval($prometheus_Main_Settings['min_height'])) {
                        fail_and_redirect('minheight');
                    }
                }
                if (isset($prometheus_Main_Settings['max_width']) && $prometheus_Main_Settings['max_width'] != '' && is_numeric($prometheus_Main_Settings['max_width'])) {
                    if (intval($image_width) != 0 && intval($image_width) > intval($prometheus_Main_Settings['max_width'])) {
                        fail_and_redirect('maxwidth');
                    }
                }
                if (isset($prometheus_Main_Settings['min_width']) && $prometheus_Main_Settings['min_width'] != '' && is_numeric($prometheus_Main_Settings['min_width'])) {
                    if (intval($image_width) != 0 && intval($image_width) < intval($prometheus_Main_Settings['min_width'])) {
                        fail_and_redirect('minwidth');
                    }
                }
                $tmpFilePath = $_FILES['post_image']['tmp_name'][$i];
                if ($tmpFilePath != "") {
                    $counter++;
                    $shortname  = $_FILES['post_image']['name'][$i];
                    $upload_dir = wp_upload_dir();
                    $dir_name   = $upload_dir['basedir'] . '/prometheus-files';
                    $dir_url    = $upload_dir['baseurl'] . '/prometheus-files';
                    if (!file_exists($dir_name)) {
                        wp_mkdir_p($dir_name);
                    }
                    $file_name = date('d-m-Y-H-i-s') . '-' . $_FILES['post_image']['name'][$i];
                    $filePath  = $dir_name . "/" . $file_name;
                    $fileURL   = $dir_url . "/" . $file_name;
                    if (move_uploaded_file($tmpFilePath, $filePath)) {
                        if (isset($prometheus_Main_Settings['auto_include']) && $prometheus_Main_Settings['auto_include'] != 'none') {
                            if ($is_image == 1) {
                                if ($featured_image == '') {
                                    $featured_image = $fileURL;
                                }
                                if (isset($prometheus_Main_Settings['image_height']) && $prometheus_Main_Settings['image_height'] !== '') {
                                    $img_height = $prometheus_Main_Settings['image_height'];
                                } else {
                                    $img_height = '';
                                }
                                if (isset($prometheus_Main_Settings['image_width']) && $prometheus_Main_Settings['image_width'] !== '') {
                                    $img_width = $prometheus_Main_Settings['image_width'];
                                } else {
                                    $img_width = '';
                                }
                                if ($prometheus_Main_Settings['auto_include'] == 'begin') {
                                    if (isset($prometheus_Main_Settings['link_images']) && $prometheus_Main_Settings['link_images'] == 'on') {
                                        
                                        $content = '<a href="' . $fileURL . '" target="_blank"</a><img height="' . $img_height . '" width="' . $img_width . '" src="' . $fileURL . '" alt="' . $_FILES['post_image']['name'][$i] . '"></a><br/><br/>' . $content;
                                    } else {
                                        $content = '<img height="' . $img_height . '" width="' . $img_width . '" src="' . $fileURL . '" alt="' . $_FILES['post_image']['name'][$i] . '"><br/><br/>' . $content;
                                    }
                                } elseif ($prometheus_Main_Settings['auto_include'] == 'end') {
                                    if (isset($prometheus_Main_Settings['link_images']) && $prometheus_Main_Settings['link_images'] == 'on') {
                                        $content = $content . '<br/><br/><a href="' . $fileURL . '" target="_blank"</a><img height="' . $img_height . '" width="' . $img_width . '" src="' . $fileURL . '" alt="' . $_FILES['post_image']['name'][$i] . '"></a>';
                                    } else {
                                        $content = $content . '<br/><br/><img height="' . $img_height . '" width="' . $img_width . '" src="' . $fileURL . '" alt="' . $_FILES['post_image']['name'][$i] . '">';
                                    }
                                }
                            } else {
                                if (isset($prometheus_Main_Settings['insert_only_images']) && $prometheus_Main_Settings['insert_only_images'] == 'on') {
                                    if ($prometheus_Main_Settings['auto_include'] == 'begin') {
                                        $content = '<a href="' . $fileURL . '">' . $_FILES['post_image']['name'][$i] . '</a><br/><br/>' . $content;
                                    } elseif ($prometheus_Main_Settings['auto_include'] == 'end') {
                                        $content = $content . '<a href="' . $fileURL . '">' . $_FILES['post_image']['name'][$i] . '</a><br/><br/>';
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if ($prometheus_Main_Settings['post_image'] != 'Hide' && isset($prometheus_Main_Settings['max_files']) && is_numeric($prometheus_Main_Settings['max_files']) && $counter > intval($prometheus_Main_Settings['max_files'])) {
            fail_and_redirect('maxfiles');
        }
        if ($prometheus_Main_Settings['post_image'] != 'Hide' && isset($prometheus_Main_Settings['min_files']) && is_numeric($prometheus_Main_Settings['min_files']) && $counter < intval($prometheus_Main_Settings['min_files'])) {
            fail_and_redirect('minfiles');
        }
        if (isset($_POST['post_category'])) {
            foreach ($_POST['post_category'] as $selected) {
                $post_category .= $selected . ",";
            }
        }
        if ($post_category == '') {
            $post_category = $prometheus_Main_Settings['default_category'];
        } else {
            $post_category = rtrim($post_category, ',');
        }
        $post_category = explode(",", $post_category);
        
        //add auto categories
        if (isset($prometheus_Main_Settings['auto_categories']) && !empty($prometheus_Main_Settings['auto_categories'])) {
            foreach ($prometheus_Main_Settings['auto_categories'] as $category) {
                if (!in_array($category, $post_category)) {
                    $post_category[] = $category;
                }
            }
        }
        $post_excerpt    = isset($_POST['post_excerpt']) ? sanitize_text_field($_POST['post_excerpt']) : $prometheus_Main_Settings['default_excerpt'];
        $post_type       = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : $prometheus_Main_Settings['default_type'];
        $accept_comments = isset($_POST['accept_comments']) ? sanitize_text_field($_POST['accept_comments']) : $prometheus_Main_Settings['default_comment'];
        $ping_status     = isset($_POST['ping_status']) ? sanitize_text_field($_POST['ping_status']) : $prometheus_Main_Settings['default_ping'];
        $password        = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : $prometheus_Main_Settings['default_password'];
        $post_format     = isset($_POST['post_format']) ? sanitize_text_field($_POST['post_format']) : $prometheus_Main_Settings['default_format'];
        //char count verification
        if ($prometheus_Main_Settings['post_title'] != 'Hide' && isset($prometheus_Main_Settings['max_chars_title']) && is_numeric($prometheus_Main_Settings['max_chars_title']) && intval($prometheus_Main_Settings['max_chars_title']) > 0) {
            if (strlen($title) > intval($prometheus_Main_Settings['max_chars_title'])) {
                fail_and_redirect('titlelong');
            }
        }
        if ($prometheus_Main_Settings['post_title'] != 'Hide' && isset($prometheus_Main_Settings['min_chars_title']) && is_numeric($prometheus_Main_Settings['min_chars_title']) && intval($prometheus_Main_Settings['min_chars_title']) > 0) {
            if (strlen($title) < intval($prometheus_Main_Settings['min_chars_title'])) {
                fail_and_redirect('titleshort');
            }
        }
        if ($prometheus_Main_Settings['post_content'] != 'Hide' && isset($prometheus_Main_Settings['max_chars_content']) && is_numeric($prometheus_Main_Settings['max_chars_content']) && intval($prometheus_Main_Settings['max_chars_content']) > 0) {
            if (strlen($content) > intval($prometheus_Main_Settings['max_chars_content'])) {
                fail_and_redirect('contentlong');
            }
        }
        if ($prometheus_Main_Settings['post_content'] != 'Hide' && isset($prometheus_Main_Settings['min_chars_content']) && is_numeric($prometheus_Main_Settings['min_chars_content']) && intval($prometheus_Main_Settings['min_chars_content']) > 0) {
            if (strlen($content) < intval($prometheus_Main_Settings['min_chars_content'])) {
                fail_and_redirect('contentshort');
            }
        }
        if (isset($prometheus_Main_Settings['max_chars_other']) && is_numeric($prometheus_Main_Settings['max_chars_other']) && intval($prometheus_Main_Settings['max_chars_other']) > 0) {
            if ($prometheus_Main_Settings['user_name'] != 'Hide' && strlen($author) > intval($prometheus_Main_Settings['max_chars_other'])) {
                fail_and_redirect('authorlong');
            }
            if ($prometheus_Main_Settings['user_email'] != 'Hide' && strlen($email) > intval($prometheus_Main_Settings['max_chars_other'])) {
                fail_and_redirect('emaillong');
            }
            if ($prometheus_Main_Settings['user_url'] != 'Hide' && strlen($url) > intval($prometheus_Main_Settings['max_chars_other'])) {
                fail_and_redirect('urllong');
            }
            if ($prometheus_Main_Settings['post_tags'] != 'Hide' && strlen($tags) > intval($prometheus_Main_Settings['max_chars_other'])) {
                fail_and_redirect('tagslong');
            }
            if ($prometheus_Main_Settings['post_excerpt'] != 'Hide' && strlen($post_excerpt) > intval($prometheus_Main_Settings['max_chars_other'])) {
                fail_and_redirect('excerptlong');
            }
            if ($prometheus_Main_Settings['password'] != 'Hide' && strlen($password) > intval($prometheus_Main_Settings['max_chars_other'])) {
                fail_and_redirect('passwordlong');
            }
        }
        if (isset($prometheus_Main_Settings['min_chars_other']) && is_numeric($prometheus_Main_Settings['min_chars_other']) && intval($prometheus_Main_Settings['min_chars_other']) > 0) {
            if ($prometheus_Main_Settings['user_name'] != 'Hide' && strlen($author) < intval($prometheus_Main_Settings['min_chars_other'])) {
                fail_and_redirect('authorshort');
            }
            if ($prometheus_Main_Settings['user_email'] != 'Hide' && strlen($email) < intval($prometheus_Main_Settings['min_chars_other'])) {
                fail_and_redirect('emailshort');
            }
            if ($prometheus_Main_Settings['user_url'] != 'Hide' && strlen($url) < intval($prometheus_Main_Settings['min_chars_other'])) {
                fail_and_redirect('urlshort');
            }
            if ($prometheus_Main_Settings['post_tags'] != 'Hide' && strlen($tags) < intval($prometheus_Main_Settings['min_chars_other'])) {
                fail_and_redirect('short');
            }
            if ($prometheus_Main_Settings['post_excerpt'] != 'Hide' && strlen($post_excerpt) < intval($prometheus_Main_Settings['min_chars_other'])) {
                fail_and_redirect('excerptshort');
            }
            if ($prometheus_Main_Settings['password'] != 'Hide' && strlen($password) < intval($prometheus_Main_Settings['min_chars_other'])) {
                fail_and_redirect('passwordshort');
            }
        }
        //unique titles verification
        if ($prometheus_Main_Settings['post_title'] != 'Hide' && isset($prometheus_Main_Settings['unique_title']) && $prometheus_Main_Settings['unique_title'] == 'on') {
            $query     = array(
                'post_status' => array(
                    'publish',
                    'pending',
                    'draft',
                    'auto-draft',
                    'future',
                    'private',
                    'inherit',
                    'trash'
                )
            );
            $post_list = get_posts($query);
            foreach ($post_list as $post) {
                if (trim(htmlspecialchars_decode($post->post_title)) == trim(htmlspecialchars_decode($title))) {
                    fail_and_redirect('duplicate');
                }
            }
        }
        //unique content verification
        if ($prometheus_Main_Settings['post_content'] != 'Hide' && isset($prometheus_Main_Settings['unique_content']) && $prometheus_Main_Settings['unique_content'] == 'on') {
            $query     = array(
                'post_status' => array(
                    'publish',
                    'pending',
                    'draft',
                    'auto-draft',
                    'future',
                    'private',
                    'inherit',
                    'trash'
                )
            );
            $post_list = get_posts($query);
            foreach ($post_list as $post) {
                if (trim(htmlspecialchars_decode($post->post_content)) == trim(htmlspecialchars_decode($content))) {
                    fail_and_redirect('duplicate2');
                }
            }
        }
        //check if not on allowed list
        if (isset($prometheus_Main_Settings['allow_names']) && $prometheus_Main_Settings['allow_names'] !== '') {
            $pieces       = explode(",", $prometheus_Main_Settings['allow_names']);
            $current_user = wp_get_current_user();
            $found        = 0;
            foreach ($pieces as $piece) {
                if (trim($piece) == trim($current_user->user_login)) {
                    $found = 1;
                }
            }
            if ($found === 0) {
                fail_and_redirect('notallowed');
            }
        }
        //check if permissions ok
        if (isset($prometheus_Main_Settings['need_login']) && $prometheus_Main_Settings['need_login'] === 'on' && is_user_logged_in()) {
            if (isset($prometheus_Main_Settings['user_categories']) && $prometheus_Main_Settings['user_categories'] !== '') {
                $priv_needed = $prometheus_Main_Settings['user_categories'];
                if ($priv_needed == 0) {
                    fail_and_redirect('nopriviledges');
                } elseif ($priv_needed == 1) {
                    $user          = wp_get_current_user();
                    $allowed_roles = array(
                        'administrator'
                    );
                    if (!array_intersect($allowed_roles, $user->roles)) {
                        fail_and_redirect('nopriviledges');
                    }
                } elseif ($priv_needed == 2) {
                    $user          = wp_get_current_user();
                    $allowed_roles = array(
                        'administrator',
                        'editor'
                    );
                    if (!array_intersect($allowed_roles, $user->roles)) {
                        fail_and_redirect('nopriviledges');
                    }
                } elseif ($priv_needed == 3) {
                    $user          = wp_get_current_user();
                    $allowed_roles = array(
                        'administrator',
                        'editor',
                        'author'
                    );
                    if (!array_intersect($allowed_roles, $user->roles)) {
                        fail_and_redirect('nopriviledges');
                    }
                } elseif ($priv_needed == 4) {
                    $user          = wp_get_current_user();
                    $allowed_roles = array(
                        'administrator',
                        'editor',
                        'author',
                        'contributor'
                    );
                    if (!array_intersect($allowed_roles, $user->roles)) {
                        fail_and_redirect('nopriviledges');
                    }
                } elseif ($priv_needed == 5) {
                    if (!is_user_logged_in()) {
                        fail_and_redirect('nopriviledges');
                    }
                }
            }
        }
        //check if not banned - ban_names
        if (isset($prometheus_Main_Settings['ban_names']) && $prometheus_Main_Settings['ban_names'] !== '') {
            $pieces       = explode(",", $prometheus_Main_Settings['ban_names']);
            $current_user = wp_get_current_user();
            foreach ($pieces as $piece) {
                if (trim($piece) == trim($current_user->user_login)) {
                    fail_and_redirect('banned');
                }
            }
        }
        //bot verification
        if (isset($prometheus_Main_Settings['spam_protect']) && $prometheus_Main_Settings['spam_protect'] === 'on') {
            if ($verify != '') {
                fail_and_redirect('bot');
            }
        }
        //captcha verification
        if (isset($prometheus_Main_Settings['post_captcha']) && $prometheus_Main_Settings['post_captcha'] != 'Hide') {
            $answer = '';
            if (isset($prometheus_Main_Settings['captcha_answer'])) {
                $answer = $prometheus_Main_Settings['captcha_answer'];
            }
            if (htmlspecialchars_decode($captcha) !== $answer) {
                fail_and_redirect('captcha');
            }
        }
        //empty fields verification
        if (isset($prometheus_Main_Settings['user_name']) && $prometheus_Main_Settings['user_name'] == 'ShowRequire') {
            if ($author == '') {
                fail_and_redirect('user');
            }
        }
        if (isset($prometheus_Main_Settings['user_email']) && $prometheus_Main_Settings['user_email'] == 'ShowRequire') {
            if ($email == '') {
                fail_and_redirect('email');
            }
        }
        if (isset($prometheus_Main_Settings['user_url']) && $prometheus_Main_Settings['user_url'] == 'ShowRequire') {
            if ($url == '') {
                fail_and_redirect('url');
            }
        }
        if (isset($prometheus_Main_Settings['post_title']) && $prometheus_Main_Settings['post_title'] == 'ShowRequire') {
            if ($title == '') {
                fail_and_redirect('title');
            }
        }
        if (isset($prometheus_Main_Settings['post_tags']) && $prometheus_Main_Settings['post_tags'] == 'ShowRequire') {
            if ($tags == '') {
                fail_and_redirect('tags');
            }
        }
        if (isset($prometheus_Main_Settings['post_category']) && $prometheus_Main_Settings['post_category'] == 'ShowRequire') {
            if (empty($post_category)) {
                fail_and_redirect('category');
            }
        }
        if (isset($prometheus_Main_Settings['post_content']) && $prometheus_Main_Settings['post_content'] == 'ShowRequire') {
            if ($content == '') {
                fail_and_redirect('content');
            }
        }
        if (isset($prometheus_Main_Settings['post_captcha']) && $prometheus_Main_Settings['post_captcha'] == 'ShowRequire') {
            if ($captcha == '') {
                fail_and_redirect('reqcaptcha');
            }
        }
        if (isset($prometheus_Main_Settings['post_excerpt']) && $prometheus_Main_Settings['post_excerpt'] == 'ShowRequire') {
            if ($post_excerpt == '') {
                fail_and_redirect('excerpt');
            }
        }
        if (isset($prometheus_Main_Settings['accept_comments']) && $prometheus_Main_Settings['accept_comments'] == 'ShowRequire') {
            if ($accept_comments == '') {
                fail_and_redirect('comments');
            }
        }
        if (isset($prometheus_Main_Settings['ping_status']) && $prometheus_Main_Settings['ping_status'] == 'ShowRequire') {
            if ($ping_status == '') {
                fail_and_redirect('ping');
            }
        }
        if (isset($prometheus_Main_Settings['password']) && $prometheus_Main_Settings['password'] == 'ShowRequire') {
            if ($password == '') {
                fail_and_redirect('password');
            }
        }
        if (isset($prometheus_Main_Settings['post_format']) && $prometheus_Main_Settings['post_format'] == 'ShowRequire') {
            if ($post_format == '') {
                fail_and_redirect('format');
            }
        }
        if (isset($prometheus_Main_Settings['post_type']) && $prometheus_Main_Settings['post_type'] == 'ShowRequire') {
            if ($post_type == '') {
                fail_and_redirect('type');
            }
        }
        if (isset($prometheus_Main_Settings['post_image']) && $prometheus_Main_Settings['post_image'] == 'ShowRequire') {
            if (empty($files)) {
                fail_and_redirect('image');
            }
        }
        //censorred words verification
        if (isset($prometheus_Main_Settings['hide_curse']) && $prometheus_Main_Settings['hide_curse'] == 'on') {
            if (isset($prometheus_Main_Settings['censor_words']) && $prometheus_Main_Settings['censor_words'] != '') {
                $badWords = array();
                $pieces   = explode(",", $prometheus_Main_Settings['censor_words']);
                foreach ($pieces as $piece) {
                    $stars = '';
                    $len   = strlen(trim($piece));
                    for ($i = 0; $i < $len; $i++) {
                        $stars .= '*';
                    }
                    $badWords[trim($piece)] = $stars;
                }
                if ($prometheus_Main_Settings['post_title'] != 'Hide') {
                    $title = strtr($title, $badWords);
                }
                if ($prometheus_Main_Settings['post_content'] != 'Hide') {
                    $content = strtr($content, $badWords);
                }
            }
        }
        
        $prometheus_new_post = array(
            'post_title' => $title,
            'post_content' => $content,
            'post_status' => $status,
            'post_author' => $user_id,
            'post_excerpt' => $post_excerpt,
            'post_type' => $post_type,
            'comment_status' => $accept_comments,
            'ping_status' => $ping_status,
            'post_password' => $password
        );
        $post_id             = wp_insert_post($prometheus_new_post);
        if (!$post_id) {
            fail_and_redirect('failed');
        } else {
            if (isset($prometheus_Main_Settings['featured_image']) && $prometheus_Main_Settings['featured_image'] === 'on') {
                if ($featured_image != '') {
                    prometheus_generate_featured_image($featured_image, $post_id);
                }
            }
            if ($post_format != 'post-format-standard') {
                $taxonomy = 'post_format';
                wp_set_post_terms($post_id, $post_format, $taxonomy);
            }
            
            wp_set_post_categories($post_id, $post_category);
            
            $name_of_tag_taxonomy = 'post_tag';
            $tags                 = explode(',', $tags);
            
            //add auto tags
            $auto_tags = explode(',', $prometheus_Main_Settings['auto_tags']);
            foreach ($auto_tags as $at) {
                if (!in_array(trim($at), $tags)) {
                    $tags[] = trim($at);
                }
            }
            wp_set_object_terms($post_id, $tags, $name_of_tag_taxonomy);
            
            //update meta data
            add_post_meta($post_id, 'prometheus_submitted_post', 'true');
            add_post_meta($post_id, 'author_name', $author);
            add_post_meta($post_id, 'author_url', $url);
            add_post_meta($post_id, 'author_email', $email);
            add_post_meta($post_id, 'author_ip', $ip);
            add_post_meta($post_id, 'author_user_agent', $user_agent);
            add_post_meta($post_id, 'author_referrer', $referrer);
            if (isset($prometheus_Main_Settings['email_alert']) && $prometheus_Main_Settings['email_alert'] === 'on') {
                if (isset($prometheus_Main_Settings['email_alert_address']) && $prometheus_Main_Settings['email_alert_address'] != '') {
                    $user = get_userdata(intval($user_id));
                    $vars = array(
                        '%%post_title%%' => $title,
                        '%%post_content%%' => $content,
                        '%%post_excerpt%%' => $post_excerpt,
                        '%%post_status%%' => $status,
                        '%%post_author%%' => $user->user_login,
                        '%%post_type%%' => $post_type,
                        '%%post_password%%' => $password,
                        '%%tags%%' => implode(',', $tags),
                        '%%category%%' => implode(',', $post_category),
                        '%%author%%' => $author,
                        '%%author_email%%' => $email,
                        '%%author_url%%' => $url,
                        '%%author_user_agent%%' => $user_agent,
                        '%%author_ip%%' => $ip,
                        '%%author_referrer%%' => $referrer,
                        '%%sitename%%' => get_bloginfo('name'),
                        '%%siteurl%%' => network_site_url('/'),
                        '%%permalink%%' => get_permalink($post_id),
                        '%%editlink%%' => get_edit_post_link($post_id)
                    );
                    $to   = $prometheus_Main_Settings['email_alert_address'];
                    if (isset($prometheus_Main_Settings['email_subject'])) {
                        $subject = strtr($prometheus_Main_Settings['email_subject'], $vars);
                    } else {
                        $subject = 'Email subject not set';
                    }
                    if (isset($prometheus_Main_Settings['email_content'])) {
                        $message = strtr($prometheus_Main_Settings['email_content'], $vars);
                    } else {
                        $message = 'Email content not set';
                    }
                    $headers = 'From: ' . $prometheus_Main_Settings['sender_email_address'] . "\r\n" . 'Reply-To: ' . $prometheus_Main_Settings['sender_email_address'] . "\r\n" . 'X-Mailer: PHP/' . phpversion() . 'Content-Type: text/html; charset=' . get_option('blog_charset', 'UTF-8') . PHP_EOL;
                    wp_mail($to, $subject, $message, $headers);
                }
            }
            if (isset($prometheus_Main_Settings['redirect_to_post']) && $prometheus_Main_Settings['redirect_to_post'] === 'on' && $status == 'publish') {
                $redirect = get_permalink($post_id);
                wp_redirect($redirect);
                exit();
            }
            
            if (isset($prometheus_Main_Settings['redirect']) && $prometheus_Main_Settings['redirect'] === 'on') {
                if (isset($prometheus_Main_Settings['redirect_url'])) {
                    $redirect = $prometheus_Main_Settings['redirect_url'];
                    $redirect = add_query_arg(array(
                        'prometheus-success' => 'ok'
                    ), $redirect);
                    wp_redirect(esc_url_raw($redirect));
                    exit();
                }
            }
            $redirect = $_SERVER['REQUEST_URI'];
            $redirect = explode('?', $redirect);
            $redirect = $redirect[0];
            $redirect = add_query_arg(array(
                'prometheus-success' => 'ok'
            ), $redirect);
            if (isset($prometheus_Main_Settings['hide_after_success']) && $prometheus_Main_Settings['hide_after_success'] === 'on') {
                $redirect = add_query_arg(array(
                    'hidden' => 'on'
                ), $redirect);
            }
            wp_redirect(esc_url_raw($redirect));
            exit();
        }
    }
}

function prometheus_generate_featured_image($image_url, $post_id)
{
    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($image_url);
    $filename   = basename($image_url);
    if (wp_mkdir_p($upload_dir['path']))
        $file = $upload_dir['path'] . '/' . $filename;
    else
        $file = $upload_dir['basedir'] . '/' . $filename;
    file_put_contents($file, $image_data);
    
    $wp_filetype = wp_check_filetype($filename, null);
    $attachment  = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id   = wp_insert_attachment($attachment, $file, $post_id);
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
    $res1        = wp_update_attachment_metadata($attach_id, $attach_data);
    $res2        = set_post_thumbnail($post_id, $attach_id);
}

function fail_and_redirect($status = 'failed')
{
    $prometheus_Main_Settings = get_option('prometheus_Main_Settings', false);
    if (isset($prometheus_Main_Settings['redirect']) && $prometheus_Main_Settings['redirect'] === 'on') {
        if (isset($prometheus_Main_Settings['redirect_url_fail'])) {
            $redirect = $prometheus_Main_Settings['redirect_url_fail'];
            $redirect = add_query_arg(array(
                'prometheus-error' => $status
            ), $redirect);
            wp_redirect(esc_url_raw($redirect));
            exit();
        }
    }
    $redirect = $_SERVER['REQUEST_URI'];
    $redirect = explode('?', $redirect);
    $redirect = $redirect[0];
    $redirect = add_query_arg(array(
        'prometheus-error' => $status
    ), $redirect);
    if (isset($prometheus_Main_Settings['hide_after_fail']) && $prometheus_Main_Settings['hide_after_fail'] === 'on') {
        $redirect = add_query_arg(array(
            'hidden' => 'on'
        ), $redirect);
    }
    if (isset($prometheus_Main_Settings['save_failed_submit']) && $prometheus_Main_Settings['save_failed_submit'] === 'on') {
        if (isset($prometheus_Main_Settings['user_name']) && $prometheus_Main_Settings['user_name'] !== 'Hide') {
            $redirect = add_query_arg(array(
                'user_name' => $_POST['user_name']
            ), $redirect);
        }
        if (isset($prometheus_Main_Settings['user_email']) && $prometheus_Main_Settings['user_email'] !== 'Hide') {
            $redirect = add_query_arg(array(
                'user_email' => $_POST['user_email']
            ), $redirect);
        }
        if (isset($prometheus_Main_Settings['user_url']) && $prometheus_Main_Settings['user_url'] !== 'Hide') {
            $redirect = add_query_arg(array(
                'user_url' => esc_url($_POST['user_url'])
            ), $redirect);
        }
        if (isset($prometheus_Main_Settings['post_title']) && $prometheus_Main_Settings['post_title'] !== 'Hide') {
            $redirect = add_query_arg(array(
                'post_title' => $_POST['post_title']
            ), $redirect);
        }
        if (isset($prometheus_Main_Settings['post_tags']) && $prometheus_Main_Settings['post_tags'] !== 'Hide') {
            $redirect = add_query_arg(array(
                'post_tags' => $_POST['post_tags']
            ), $redirect);
        }
        if (isset($prometheus_Main_Settings['post_content']) && $prometheus_Main_Settings['post_content'] !== 'Hide') {
            $redirect = add_query_arg(array(
                'post_content' => $_POST['post_content']
            ), $redirect);
        }
        if (isset($prometheus_Main_Settings['post_excerpt']) && $prometheus_Main_Settings['post_excerpt'] !== 'Hide') {
            $redirect = add_query_arg(array(
                'post_excerpt' => $_POST['post_excerpt']
            ), $redirect);
        }
    }
    wp_redirect(esc_url_raw($redirect));
    exit();
}

add_filter('widget_text', 'do_shortcode', 10);
add_action('parse_request', 'prometheus_parse_form', 1);

function prometheus_is_admin()
{
    return in_array('administrator', wp_get_current_user()->roles);
}

add_action('admin_enqueue_scripts', 'prometheus_admin_load_files');
function prometheus_admin_load_files()
{
    wp_register_style('prometheus-browser-style', plugins_url('styles/prometheus-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('prometheus-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('prometheus-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('prometheus-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('prometheus-settings-app', plugins_url('res/prometheus-angular.js', __FILE__), array(), '1.0.0', true);
}
function prometheus_form_add_scripts()
{
    $prometheus_Main_Settings = get_option('prometheus_Main_Settings', false);
    if ($prometheus_Main_Settings['form_theme'] === 'theme') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'light') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form-light.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'dark') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form-dark.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'blue') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form-blue.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'red') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form-red.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'green') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form-green.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'transparent') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form-transparent.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'custom') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } elseif ($prometheus_Main_Settings['form_theme'] === 'own') {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form-own.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    } else {
        wp_register_style('prometheus-form-css', plugins_url('styles/prometheus-form.css', __FILE__), false, '1.0.0');
        wp_enqueue_style('prometheus-form-css');
    }
}
add_action('wp_enqueue_scripts', 'prometheus_form_add_scripts');

require(dirname(__FILE__) . "/res/prometheus-main.php");
require(dirname(__FILE__) . "/res/prometheus-statistics.php");
require(dirname(__FILE__) . "/res/prometheus-texts.php");
?>