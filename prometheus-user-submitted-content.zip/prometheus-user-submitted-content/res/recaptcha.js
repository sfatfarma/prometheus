  jQuery("#prometheus-submit-post").click(function(e){
        var data_2;
    jQuery.ajax({
                type: "POST",
                url: settings.url_to_php,
                data: jQuery('#prometheus_form').serialize() + "&secret=" + settings.secret,
                async:false,
                success: function(data) {
                 if(data.nocaptcha==="true") {
               data_2=1;
                  } else if(data.spam==="true") {
               data_2=2;
                  } else {
               data_2=0;
                  }
                }
            });
            
            if(data_2!=0) {
              e.preventDefault();
              if(data_2==1) {
                alert(settings.incorrect);
              } else {
                alert(settings.spam);
              }
            } else {
                jQuery("#prometheus_form").submit();
           }
  });