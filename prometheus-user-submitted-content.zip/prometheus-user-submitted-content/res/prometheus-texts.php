<?php
function prometheus_default_texts()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('prometheus_option_group2');
    do_settings_sections('prometheus_option_group2');
    $prometheus_Form_Settings = get_option('prometheus_Form_Settings', false);
    if (isset($prometheus_Form_Settings['user_name'])) {
        $user_name = $prometheus_Form_Settings['user_name'];
    } else {
        $user_name = '';
    }
    if (isset($prometheus_Form_Settings['user_email'])) {
        $user_email = $prometheus_Form_Settings['user_email'];
    } else {
        $user_email = '';
    }
    if (isset($prometheus_Form_Settings['post_password'])) {
        $post_password = $prometheus_Form_Settings['post_password'];
    } else {
        $post_password = '';
    }
    if (isset($prometheus_Form_Settings['post_excerpt'])) {
        $post_excerpt = $prometheus_Form_Settings['post_excerpt'];
    } else {
        $post_excerpt = '';
    }
    if (isset($prometheus_Form_Settings['post_category'])) {
        $post_category = $prometheus_Form_Settings['post_category'];
    } else {
        $post_category = '';
    }
    if (isset($prometheus_Form_Settings['accept_comments'])) {
        $accept_comments = $prometheus_Form_Settings['accept_comments'];
    } else {
        $accept_comments = '';
    }
    if (isset($prometheus_Form_Settings['accept_pings'])) {
        $accept_pings = $prometheus_Form_Settings['accept_pings'];
    } else {
        $accept_pings = '';
    }
    if (isset($prometheus_Form_Settings['post_format'])) {
        $post_format = $prometheus_Form_Settings['post_format'];
    } else {
        $post_format = '';
    }
    if (isset($prometheus_Form_Settings['post_attachment'])) {
        $post_attachment = $prometheus_Form_Settings['post_attachment'];
    } else {
        $post_attachment = '';
    }
    if (isset($prometheus_Form_Settings['post_content'])) {
        $post_content = $prometheus_Form_Settings['post_content'];
    } else {
        $post_content = '';
    }
    if (isset($prometheus_Form_Settings['post_or_page'])) {
        $post_or_page = $prometheus_Form_Settings['post_or_page'];
    } else {
        $post_or_page = '';
    }
    if (isset($prometheus_Form_Settings['bot_trap'])) {
        $bot_trap = $prometheus_Form_Settings['bot_trap'];
    } else {
        $bot_trap = '';
    }
    if (isset($prometheus_Form_Settings['submit_post'])) {
        $submit_post = $prometheus_Form_Settings['submit_post'];
    } else {
        $submit_post = '';
    }
    if (isset($prometheus_Form_Settings['duplicate'])) {
        $duplicate = $prometheus_Form_Settings['duplicate'];
    } else {
        $duplicate = '';
    }
    if (isset($prometheus_Form_Settings['duplicate2'])) {
        $duplicate2 = $prometheus_Form_Settings['duplicate2'];
    } else {
        $duplicate2 = '';
    }
    if (isset($prometheus_Form_Settings['failed'])) {
        $failed = $prometheus_Form_Settings['failed'];
    } else {
        $failed = '';
    }
    if (isset($prometheus_Form_Settings['captcha'])) {
        $captcha = $prometheus_Form_Settings['captcha'];
    } else {
        $captcha = '';
    }
    if (isset($prometheus_Form_Settings['bot'])) {
        $bot = $prometheus_Form_Settings['bot'];
    } else {
        $bot = '';
    }
    if (isset($prometheus_Form_Settings['banned'])) {
        $banned = $prometheus_Form_Settings['banned'];
    } else {
        $banned = '';
    }
    if (isset($prometheus_Form_Settings['user'])) {
        $user = $prometheus_Form_Settings['user'];
    } else {
        $user = '';
    }
    if (isset($prometheus_Form_Settings['email'])) {
        $email = $prometheus_Form_Settings['email'];
    } else {
        $email = '';
    }
    if (isset($prometheus_Form_Settings['url'])) {
        $url = $prometheus_Form_Settings['url'];
    } else {
        $url = '';
    }
    if (isset($prometheus_Form_Settings['title'])) {
        $title = $prometheus_Form_Settings['title'];
    } else {
        $title = '';
    }
    if (isset($prometheus_Form_Settings['tags'])) {
        $tags = $prometheus_Form_Settings['tags'];
    } else {
        $tags = '';
    }
    if (isset($prometheus_Form_Settings['category'])) {
        $category = $prometheus_Form_Settings['category'];
    } else {
        $category = '';
    }
    if (isset($prometheus_Form_Settings['content'])) {
        $content = $prometheus_Form_Settings['content'];
    } else {
        $content = '';
    }
    if (isset($prometheus_Form_Settings['reqcaptcha'])) {
        $reqcaptcha = $prometheus_Form_Settings['reqcaptcha'];
    } else {
        $reqcaptcha = '';
    }
    if (isset($prometheus_Form_Settings['excerpt'])) {
        $excerpt = $prometheus_Form_Settings['excerpt'];
    } else {
        $excerpt = '';
    }
    if (isset($prometheus_Form_Settings['comments'])) {
        $comments = $prometheus_Form_Settings['comments'];
    } else {
        $comments = '';
    }
    if (isset($prometheus_Form_Settings['ping'])) {
        $ping = $prometheus_Form_Settings['ping'];
    } else {
        $ping = '';
    }
    if (isset($prometheus_Form_Settings['password'])) {
        $password = $prometheus_Form_Settings['password'];
    } else {
        $password = '';
    }
    if (isset($prometheus_Form_Settings['format'])) {
        $format = $prometheus_Form_Settings['format'];
    } else {
        $format = '';
    }
    if (isset($prometheus_Form_Settings['type'])) {
        $type = $prometheus_Form_Settings['type'];
    } else {
        $type = '';
    }
    if (isset($prometheus_Form_Settings['image'])) {
        $image = $prometheus_Form_Settings['image'];
    } else {
        $image = '';
    }
    if (isset($prometheus_Form_Settings['notallowed'])) {
        $notallowed = $prometheus_Form_Settings['notallowed'];
    } else {
        $notallowed = '';
    }
    if (isset($prometheus_Form_Settings['nopriviledges'])) {
        $nopriviledges = $prometheus_Form_Settings['nopriviledges'];
    } else {
        $nopriviledges = '';
    }
    if (isset($prometheus_Form_Settings['titlelong'])) {
        $titlelong = $prometheus_Form_Settings['titlelong'];
    } else {
        $titlelong = '';
    }
    if (isset($prometheus_Form_Settings['titleshort'])) {
        $titleshort = $prometheus_Form_Settings['titleshort'];
    } else {
        $titleshort = '';
    }
    if (isset($prometheus_Form_Settings['contentlong'])) {
        $contentlong = $prometheus_Form_Settings['contentlong'];
    } else {
        $contentlong = '';
    }
    if (isset($prometheus_Form_Settings['contentshort'])) {
        $contentshort = $prometheus_Form_Settings['contentshort'];
    } else {
        $contentshort = '';
    }
    if (isset($prometheus_Form_Settings['authorlong'])) {
        $authorlong = $prometheus_Form_Settings['authorlong'];
    } else {
        $authorlong = '';
    }
    if (isset($prometheus_Form_Settings['authorshort'])) {
        $authorshort = $prometheus_Form_Settings['authorshort'];
    } else {
        $authorshort = '';
    }
    if (isset($prometheus_Form_Settings['emaillong'])) {
        $emaillong = $prometheus_Form_Settings['emaillong'];
    } else {
        $emaillong = '';
    }
    if (isset($prometheus_Form_Settings['emailshort'])) {
        $emailshort = $prometheus_Form_Settings['emailshort'];
    } else {
        $emailshort = '';
    }
    if (isset($prometheus_Form_Settings['urllong'])) {
        $urllong = $prometheus_Form_Settings['urllong'];
    } else {
        $urllong = '';
    }
    if (isset($prometheus_Form_Settings['urlshort'])) {
        $urlshort = $prometheus_Form_Settings['urlshort'];
    } else {
        $urlshort = '';
    }
    if (isset($prometheus_Form_Settings['tagslong'])) {
        $tagslong = $prometheus_Form_Settings['tagslong'];
    } else {
        $tagslong = '';
    }
    if (isset($prometheus_Form_Settings['tagsshort'])) {
        $tagsshort = $prometheus_Form_Settings['tagsshort'];
    } else {
        $tagsshort = '';
    }
    if (isset($prometheus_Form_Settings['excerptlong'])) {
        $excerptlong = $prometheus_Form_Settings['excerptlong'];
    } else {
        $excerptlong = '';
    }
    if (isset($prometheus_Form_Settings['excerptshort'])) {
        $excerptshort = $prometheus_Form_Settings['excerptshort'];
    } else {
        $excerptshort = '';
    }
    if (isset($prometheus_Form_Settings['passwordlong'])) {
        $passwordlong = $prometheus_Form_Settings['passwordlong'];
    } else {
        $passwordlong = '';
    }
    if (isset($prometheus_Form_Settings['passwordshort'])) {
        $passwordshort = $prometheus_Form_Settings['passwordshort'];
    } else {
        $passwordshort = '';
    }
    if (isset($prometheus_Form_Settings['maxfiles'])) {
        $maxfiles = $prometheus_Form_Settings['maxfiles'];
    } else {
        $maxfiles = '';
    }
    if (isset($prometheus_Form_Settings['maxsize'])) {
        $maxsize = $prometheus_Form_Settings['maxsize'];
    } else {
        $maxsize = '';
    }
    if (isset($prometheus_Form_Settings['minsize'])) {
        $minsize = $prometheus_Form_Settings['minsize'];
    } else {
        $minsize = '';
    }
    if (isset($prometheus_Form_Settings['minfiles'])) {
        $minfiles = $prometheus_Form_Settings['minfiles'];
    } else {
        $minfiles = '';
    }
    if (isset($prometheus_Form_Settings['notallowedextension'])) {
        $notallowedextension = $prometheus_Form_Settings['notallowedextension'];
    } else {
        $notallowedextension = '';
    }
    if (isset($prometheus_Form_Settings['maxheight'])) {
        $maxheight = $prometheus_Form_Settings['maxheight'];
    } else {
        $maxheight = '';
    }
    if (isset($prometheus_Form_Settings['minheight'])) {
        $minheight = $prometheus_Form_Settings['minheight'];
    } else {
        $minheight = '';
    }
    if (isset($prometheus_Form_Settings['maxwidth'])) {
        $maxwidth = $prometheus_Form_Settings['maxwidth'];
    } else {
        $maxwidth = '';
    }
    if (isset($prometheus_Form_Settings['minwidth'])) {
        $minwidth = $prometheus_Form_Settings['minwidth'];
    } else {
        $minwidth = '';
    }
    if (isset($prometheus_Form_Settings['maxurls'])) {
        $maxurls = $prometheus_Form_Settings['maxurls'];
    } else {
        $maxurls = '';
    }
    if (isset($prometheus_Form_Settings['unknown'])) {
        $unknown = $prometheus_Form_Settings['unknown'];
    } else {
        $unknown = '';
    }
    if (isset($prometheus_Form_Settings['error_string'])) {
        $error_string = $prometheus_Form_Settings['error_string'];
    } else {
        $error_string = '';
    }
    if (isset($prometheus_Form_Settings['post_tags'])) {
        $post_tags = $prometheus_Form_Settings['post_tags'];
    } else {
        $post_tags = '';
    }
    if (isset($prometheus_Form_Settings['post_title'])) {
        $post_title = $prometheus_Form_Settings['post_title'];
    } else {
        $post_title = '';
    }
    if (isset($prometheus_Form_Settings['user_url'])) {
        $user_url = $prometheus_Form_Settings['user_url'];
    } else {
        $user_url = '';
    }
    if (isset($prometheus_Form_Settings['success_string'])) {
        $success_string = $prometheus_Form_Settings['success_string'];
    } else {
        $success_string = '';
    }
    if (isset($prometheus_Form_Settings['category_default'])) {
        $category_default = $prometheus_Form_Settings['category_default'];
    } else {
        $category_default = '';
    }
    if (isset($prometheus_Form_Settings['deny_string'])) {
        $deny_string = $prometheus_Form_Settings['deny_string'];
    } else {
        $deny_string = '';
    }
    if (isset($prometheus_Form_Settings['accept_string'])) {
        $accept_string = $prometheus_Form_Settings['accept_string'];
    } else {
        $accept_string = '';
    }
    if (isset($prometheus_Form_Settings['is_page'])) {
        $is_page = $prometheus_Form_Settings['is_page'];
    } else {
        $is_page = '';
    }
    if (isset($prometheus_Form_Settings['is_post'])) {
        $is_post = $prometheus_Form_Settings['is_post'];
    } else {
        $is_post = '';
    }
    if (isset($prometheus_Form_Settings['is_standard'])) {
        $is_standard = $prometheus_Form_Settings['is_standard'];
    } else {
        $is_standard = '';
    }
    if (isset($prometheus_Form_Settings['is_aside'])) {
        $is_aside = $prometheus_Form_Settings['is_aside'];
    } else {
        $is_aside = '';
    }
    if (isset($prometheus_Form_Settings['is_gallery'])) {
        $is_gallery = $prometheus_Form_Settings['is_gallery'];
    } else {
        $is_gallery = '';
    }
    if (isset($prometheus_Form_Settings['is_link'])) {
        $is_link = $prometheus_Form_Settings['is_link'];
    } else {
        $is_link = '';
    }
    if (isset($prometheus_Form_Settings['is_image'])) {
        $is_image = $prometheus_Form_Settings['is_image'];
    } else {
        $is_image = '';
    }
    if (isset($prometheus_Form_Settings['is_quote'])) {
        $is_quote = $prometheus_Form_Settings['is_quote'];
    } else {
        $is_quote = '';
    }
    if (isset($prometheus_Form_Settings['is_status'])) {
        $is_status = $prometheus_Form_Settings['is_status'];
    } else {
        $is_status = '';
    }
    if (isset($prometheus_Form_Settings['is_video'])) {
        $is_video = $prometheus_Form_Settings['is_video'];
    } else {
        $is_video = '';
    }
    if (isset($prometheus_Form_Settings['is_audio'])) {
        $is_audio = $prometheus_Form_Settings['is_audio'];
    } else {
        $is_audio = '';
    }
    if (isset($prometheus_Form_Settings['is_chat'])) {
        $is_chat = $prometheus_Form_Settings['is_chat'];
    } else {
        $is_chat = '';
    }
?>
<script>
                var prometheus_admin_json = {
                    user_name: '<?php
    echo $user_name;
?>',                user_email: '<?php
    echo $user_email;
?>',                post_category: '<?php
    echo $post_category;
?>',                post_excerpt: '<?php
    echo $post_excerpt;
?>',                post_password: '<?php
    echo $post_password;
?>',                accept_comments: '<?php
    echo $accept_comments;
?>',                accept_pings: '<?php
    echo $accept_pings;
?>',                post_format: '<?php
    echo $post_format;
?>',                post_content: '<?php
    echo $post_content;
?>',                post_attachment: '<?php
    echo $post_attachment;
?>',                post_or_page: '<?php
    echo $post_or_page;
?>',                bot_trap: '<?php
    echo $bot_trap;
?>',                submit_post: '<?php
    echo $submit_post;
?>',                duplicate: '<?php
    echo $duplicate;
?>',                duplicate2: '<?php
    echo $duplicate2;
?>',                failed: '<?php
    echo $failed;
?>',                captcha: '<?php
    echo $captcha;
?>',                bot: '<?php
    echo $bot;
?>',                banned: '<?php
    echo $banned;
?>',                user: '<?php
    echo $user;
?>',                email: '<?php
    echo $email;
?>',                url: '<?php
    echo $url;
?>',                title: '<?php
    echo $title;
?>',                tags: '<?php
    echo $tags;
?>',                category: '<?php
    echo $category;
?>',                content: '<?php
    echo $content;
?>',                reqcaptcha: '<?php
    echo $reqcaptcha;
?>',                excerpt: '<?php
    echo $excerpt;
?>',                comments: '<?php
    echo $comments;
?>',                ping: '<?php
    echo $ping;
?>',                password: '<?php
    echo $password;
?>',                format: '<?php
    echo $format;
?>',                type: '<?php
    echo $type;
?>',                image: '<?php
    echo $image;
?>',                notallowed: '<?php
    echo $notallowed;
?>',                nopriviledges: '<?php
    echo $nopriviledges;
?>',                titlelong: '<?php
    echo $titlelong;
?>',                titleshort: '<?php
    echo $titleshort;
?>',                contentlong: '<?php
    echo $contentlong;
?>',                contentshort: '<?php
    echo $contentshort;
?>',                authorlong: '<?php
    echo $authorlong;
?>',                authorshort: '<?php
    echo $authorshort;
?>',                emaillong: '<?php
    echo $emaillong;
?>',                emailshort: '<?php
    echo $emailshort;
?>',                urllong: '<?php
    echo $urllong;
?>',                urlshort: '<?php
    echo $urlshort;
?>',                tagsshort: '<?php
    echo $tagsshort;
?>',                tagslong: '<?php
    echo $tagslong;
?>',                excerptlong: '<?php
    echo $excerptlong;
?>',                excerptshort: '<?php
    echo $excerptshort;
?>',                passwordlong: '<?php
    echo $passwordlong;
?>',                passwordshort: '<?php
    echo $passwordshort;
?>',                maxfiles: '<?php
    echo $maxfiles;
?>',                maxsize: '<?php
    echo $maxsize;
?>',                minsize: '<?php
    echo $minsize;
?>',                minfiles: '<?php
    echo $minfiles;
?>',                notallowedextension: '<?php
    echo $notallowedextension;
?>',                maxheight: '<?php
    echo $maxheight;
?>',                minheight: '<?php
    echo $minheight;
?>',                maxwidth: '<?php
    echo $maxwidth;
?>',                minwidth: '<?php
    echo $minwidth;
?>',                maxurls: '<?php
    echo $maxurls;
?>',                unknown: '<?php
    echo $unknown;
?>',                error_string: '<?php
    echo $error_string;
?>',                post_tags: '<?php
    echo $post_tags;
?>',                post_title: '<?php
    echo $post_title;
?>',                user_url: '<?php
    echo $user_url;
?>',                success_string: '<?php
    echo $success_string;
?>',                category_default: '<?php
    echo $category_default;
?>',                accept_string: '<?php
    echo $accept_string;
?>',                deny_string: '<?php
    echo $deny_string;
?>',                is_post: '<?php
    echo $is_post;
?>',                is_page: '<?php
    echo $is_page;
?>',                is_standard: '<?php
    echo $is_standard;
?>',                is_aside: '<?php
    echo $is_aside;
?>',                is_gallery: '<?php
    echo $is_gallery;
?>',                is_image: '<?php
    echo $is_image;
?>',                is_quote: '<?php
    echo $is_quote;
?>',                is_status: '<?php
    echo $is_status;
?>',                is_link: '<?php
    echo $is_link;
?>',                is_video: '<?php
    echo $is_video;
?>',                is_audio: '<?php
    echo $is_audio;
?>',                is_chat: '<?php
    echo $is_chat;
?>'
}
</script>

<div ng-app="prosettingsApp" ng-controller="prosettingsController" ng-cloak ng-init="initialized()">
<h3>Form Text Settings:</h3>
                    <table><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'User Name' textfield.";
?>
                        </div>
                    </div>
                    <b>'User Name' Field Text:</b>
                    </td><td>
                    <div class="hideReg">
                    <input type="text" name="prometheus_Form_Settings[user_name]" ng-model="settings.user_name">
                    </div>
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'User Email' textfield.";
?>
                        </div>
                    </div>
                    <b>'User Email' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[user_email]" ng-model="settings.user_email">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'User URL' textfield.";
?>
                        </div>
                    </div>
                    <b>'User URL' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[user_url]" ng-model="settings.user_url">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Title' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Title' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_title]" ng-model="settings.post_title">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Tags' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Tags' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_tags]" ng-model="settings.post_tags">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Category' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Category' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_category]" ng-model="settings.post_category">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Excerpt' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Excerpt' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_excerpt]" ng-model="settings.post_excerpt">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Password' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Password' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_password]" ng-model="settings.post_password">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Comments' textfield.";
?>
                        </div>
                    </div>
                    <b>'Accept Comments' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[accept_comments]" ng-model="settings.accept_comments">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Accept Pings' textfield.";
?>
                        </div>
                    </div>
                    <b>'Accept Pings' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[accept_pings]" ng-model="settings.accept_pings">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Format' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_format]" ng-model="settings.post_format">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post or Page' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post or Page' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_or_page]" ng-model="settings.post_or_page">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Attachment' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Attachment' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_attachment]" ng-model="settings.post_attachment">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Post Content' textfield.";
?>
                        </div>
                    </div>
                    <b>'Post Content' Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[post_content]" ng-model="settings.post_content">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Bot Trap'  invisible textfield.";
?>
                        </div>
                    </div>
                    <b>'Bot Trap' Invisible Field Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[bot_trap]" ng-model="settings.bot_trap">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the text you want to show for the 'Submit Post' button.";
?>
                        </div>
                    </div>
                    <b>'Submit Post' Button Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[submit_post]" ng-model="settings.submit_post">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text that will be shown on successful post submission.";
?>
                        </div>
                    </div>
                    <b>Successful Post Submission Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[success_string]" ng-model="settings.success_string">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the category selection default value.";
?>
                        </div>
                    </div>
                    <b>Category Select Default Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[category_default]" ng-model="settings.category_default">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be show for the 'Accept' option in the 'Comment Enabling' and 'Ping Enabling' dropdowns.";
?>
                        </div>
                    </div>
                    <b>'Comment-Enable' and 'Ping Enable' Accept Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[accept_string]" ng-model="settings.accept_string">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be show for the 'Deny' option in the 'Comment Enabling' and 'Ping Enabling' dropdowns.";
?>
                        </div>
                    </div>
                    <b>'Comment-Enable' and 'Ping Enable' Deny Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[deny_string]" ng-model="settings.deny_string">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post type selection field for the 'Post' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Type' Selection Field 'Post' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_post]" ng-model="settings.is_post">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post type selection field for the 'Page' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Type' Selection Field 'Page' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_page]" ng-model="settings.is_page">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Stadard' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Standard' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_standard]" ng-model="settings.is_standard">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Aside' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Aside' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_aside]" ng-model="settings.is_aside">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Gallery' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Gallery' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_gallery]" ng-model="settings.is_gallery">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Link' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Link' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_link]" ng-model="settings.is_link">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Image' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Image' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_image]" ng-model="settings.is_image">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Quote' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Quote' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_quote]" ng-model="settings.is_quote">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Status' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Status' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_status]" ng-model="settings.is_status">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Video' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Video' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_video]" ng-model="settings.is_video">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Audio' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Audio' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_audio]" ng-model="settings.is_audio">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text to be shown in the Post format selection field for the 'Chat' type option.";
?>
                        </div>
                    </div>
                    <b>'Post Format' Selection Field 'Chat' Option Text:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[is_chat]" ng-model="settings.is_chat">
                    </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
                    <h3>Error Strings:</h3>
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for duplicate post title";
?>
                        </div>
                    </div>
                    <b>Duplicate Post Title Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[duplicate]" ng-model="settings.duplicate">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for duplicate post content";
?>
                        </div>
                    </div>
                    <b>Duplicate Post Content Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[duplicate2]" ng-model="settings.duplicate2">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Generic submit failed error. This is usually a WordPress bug.";
?>
                        </div>
                    </div>
                    <b>Post Submit Failed Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[failed]" ng-model="settings.failed">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for incorrect captcha";
?>
                        </div>
                    </div>
                    <b>Captcha Incorrect Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[captcha]" ng-model="settings.captcha">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for spam bot detection";
?>
                        </div>
                    </div>
                    <b>Bot Detection Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[bot]" ng-model="settings.bot">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for banned users (on 'Banned Users' List)";
?>
                        </div>
                    </div>
                    <b>User Banned Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[banned]" ng-model="settings.banned">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for user name required error";
?>
                        </div>
                    </div>
                    <b>User Name Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[user]" ng-model="settings.user">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for email required error";
?>
                        </div>
                    </div>
                    <b>Email Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[email]" ng-model="settings.email">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for url required error";
?>
                        </div>
                    </div>
                    <b>Url Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[url]" ng-model="settings.url">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for title required error";
?>
                        </div>
                    </div>
                    <b>Title Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[title]" ng-model="settings.title">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for tags required error";
?>
                        </div>
                    </div>
                    <b>Tags Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[tags]" ng-model="settings.tags">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for category required error";
?>
                        </div>
                    </div>
                    <b>Category Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[category]" ng-model="settings.category">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for content required error";
?>
                        </div>
                    </div>
                    <b>Content Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[content]" ng-model="settings.content">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for recaptcha required error";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[reqcaptcha]" ng-model="settings.reqcaptcha">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for excerpt required error";
?>
                        </div>
                    </div>
                    <b>Excerpt Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[excerpt]" ng-model="settings.excerpt">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for comments required error";
?>
                        </div>
                    </div>
                    <b>Comments Enabling Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[comments]" ng-model="settings.comments">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for ping required error";
?>
                        </div>
                    </div>
                    <b>Ping Enabling Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[ping]" ng-model="settings.ping">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for password required error";
?>
                        </div>
                    </div>
                    <b>Password Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[password]" ng-model="settings.password">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for format required error";
?>
                        </div>
                    </div>
                    <b>Format Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[format]" ng-model="settings.format">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for type required error";
?>
                        </div>
                    </div>
                    <b>Post Type Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[type]" ng-model="settings.type">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for image required error";
?>
                        </div>
                    </div>
                    <b>Post Image Required Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[image]" ng-model="settings.image">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for not allowed users (not on the 'Allowed List')";
?>
                        </div>
                    </div>
                    <b>Not Allowed Users Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[notallowed]" ng-model="settings.notallowed">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for nopriviledges error (priviledge to low to post). Defined by 'User Categories Allowed to Submit Posts'.";
?>
                        </div>
                    </div>
                    <b>Not Enough Priviledges Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[nopriviledges]" ng-model="settings.nopriviledges">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for title too long.";
?>
                        </div>
                    </div>
                    <b>Post Title Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[titlelong]" ng-model="settings.titlelong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for title too short";
?>
                        </div>
                    </div>
                    <b>Title Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[titleshort]" ng-model="settings.titleshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for content too long.";
?>
                        </div>
                    </div>
                    <b>Content Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[contentlong]" ng-model="settings.contentlong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for content too short.";
?>
                        </div>
                    </div>
                    <b>Content Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[contentshort]" ng-model="settings.contentshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for author too long.";
?>
                        </div>
                    </div>
                    <b>Author Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[authorlong]" ng-model="settings.authorlong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for author too short.";
?>
                        </div>
                    </div>
                    <b>Author Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[authorshort]" ng-model="settings.authorshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for email too long.";
?>
                        </div>
                    </div>
                    <b>Email Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[emaillong]" ng-model="settings.emaillong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for email too short.";
?>
                        </div>
                    </div>
                    <b>Email Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[emailshort]" ng-model="settings.emailshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for URL too long.";
?>
                        </div>
                    </div>
                    <b>URL Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[urllong]" ng-model="settings.urllong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for URL too short.";
?>
                        </div>
                    </div>
                    <b>URL Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[urlshort]" ng-model="settings.urlshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for tags too long.";
?>
                        </div>
                    </div>
                    <b>Tags Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[tagslong]" ng-model="settings.tagslong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for tags too short.";
?>
                        </div>
                    </div>
                    <b>Tags Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[tagsshort]" ng-model="settings.tagsshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for excerpt too long.";
?>
                        </div>
                    </div>
                    <b>Excerpt Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[excerptlong]" ng-model="settings.excerptlong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for excerpt too short.";
?>
                        </div>
                    </div>
                    <b>Excerpt Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[excerptshort]" ng-model="settings.excerptshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for password too long.";
?>
                        </div>
                    </div>
                    <b>Password Too Long Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[passwordlong]" ng-model="settings.passwordlong">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Error string for password too short.";
?>
                        </div>
                    </div>
                    <b>Password Too Short Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[passwordshort]" ng-model="settings.passwordshort">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Maximum number of uploaded files error.";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Uploaded Files Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[maxfiles]" ng-model="settings.maxfiles">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Maximum file size exceeded error.";
?>
                        </div>
                    </div>
                    <b>Maximum File Size Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[maxsize]" ng-model="settings.maxsize">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Minimum file size not met error.";
?>
                        </div>
                    </div>
                    <b>Minimum File Size Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[minsize]" ng-model="settings.minsize">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Minimum number of files not met.";
?>
                        </div>
                    </div>
                    <b>Mimimum Number of Files Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[minfiles]" ng-model="settings.minfiles">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Submitted files extensions not allowed error.";
?>
                        </div>
                    </div>
                    <b>Submitted File Extensions Not Allowed Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[notallowedextension]" ng-model="settings.notallowedextension">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Submitted image exceeds max image height error";
?>
                        </div>
                    </div>
                    <b>Submitted Image Max Height Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[maxheight]" ng-model="settings.maxheight">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Submitted image min height not met error";
?>
                        </div>
                    </div>
                    <b>Submitted Image Min Height Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[minheight]" ng-model="settings.minheight">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Submitted image exceeds max image width error";
?>
                        </div>
                    </div>
                    <b>Submitted Image Max Width Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[maxwidth]" ng-model="settings.maxwidth">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Submitted image min width not met error";
?>
                        </div>
                    </div>
                    <b>Submitted Image Min Width Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[minwidth]" ng-model="settings.minwidth">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Maximum URL Count exceeded in post content error";
?>
                        </div>
                    </div>
                    <b>Max URL Count Exceeded Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[maxurls]" ng-model="settings.maxurls">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Unknown Error String - this should not appear at all.";
?>
                        </div>
                    </div>
                    <b>Unknown Error:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[unknown]" ng-model="settings.unknown">
                    </td></tr><tr><td>

        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The error string that will mark the returned errors. Eg: 'Form Error: '";
?>
                        </div>
                    </div>
                    <b>Error String that Will Mark the Returned Errors:</b>
                    </td><td>
                    <input type="text" name="prometheus_Form_Settings[error_string]" ng-model="settings.error_string">
        </td></tr></table>
        </div>
<div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
?>