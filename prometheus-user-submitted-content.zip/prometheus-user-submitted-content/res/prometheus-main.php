<?php
function prometheus_admin_settings()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('prometheus_option_group');
    do_settings_sections('prometheus_option_group');
    $prometheus_Main_Settings = get_option('prometheus_Main_Settings', false);
    if (isset($prometheus_Main_Settings['prometheus_enabled'])) {
        $prometheus_enabled = $prometheus_Main_Settings['prometheus_enabled'];
    } else {
        $prometheus_enabled = '';
    }
    if (isset($prometheus_Main_Settings['need_login'])) {
        $need_login = $prometheus_Main_Settings['need_login'];
    } else {
        $need_login = '';
    }
    if (isset($prometheus_Main_Settings['need_login_message'])) {
        $need_login_message = $prometheus_Main_Settings['need_login_message'];
    } else {
        $need_login_message = '';
    }
    if (isset($prometheus_Main_Settings['anon_users_name'])) {
        $anon_users_name = $prometheus_Main_Settings['anon_users_name'];
    } else {
        $anon_users_name = '';
    }
    if (isset($prometheus_Main_Settings['user_name'])) {
        $user_name = $prometheus_Main_Settings['user_name'];
    } else {
        $user_name = '';
    }
    if (isset($prometheus_Main_Settings['user_email'])) {
        $user_email = $prometheus_Main_Settings['user_email'];
    } else {
        $user_email = '';
    }
    if (isset($prometheus_Main_Settings['user_url'])) {
        $user_url = $prometheus_Main_Settings['user_url'];
    } else {
        $user_url = '';
    }
    if (isset($prometheus_Main_Settings['post_title'])) {
        $post_title = $prometheus_Main_Settings['post_title'];
    } else {
        $post_title = '';
    }
    if (isset($prometheus_Main_Settings['post_tags'])) {
        $post_tags = $prometheus_Main_Settings['post_tags'];
    } else {
        $post_tags = '';
    }
    if (isset($prometheus_Main_Settings['post_category'])) {
        $post_category = $prometheus_Main_Settings['post_category'];
    } else {
        $post_category = '';
    }
    if (isset($prometheus_Main_Settings['post_captcha'])) {
        $post_captcha = $prometheus_Main_Settings['post_captcha'];
    } else {
        $post_captcha = '';
    }
    if (isset($prometheus_Main_Settings['post_content'])) {
        $post_content = $prometheus_Main_Settings['post_content'];
    } else {
        $post_content = '';
    }
    if (isset($prometheus_Main_Settings['post_image'])) {
        $post_image = $prometheus_Main_Settings['post_image'];
    } else {
        $post_image = '';
    }
    if (isset($prometheus_Main_Settings['captcha_question'])) {
        $captcha_question = $prometheus_Main_Settings['captcha_question'];
    } else {
        $captcha_question = '';
    }
    if (isset($prometheus_Main_Settings['captcha_answer'])) {
        $captcha_answer = $prometheus_Main_Settings['captcha_answer'];
    } else {
        $captcha_answer = '';
    }
    if (isset($prometheus_Main_Settings['redirect'])) {
        $redirect = $prometheus_Main_Settings['redirect'];
    } else {
        $redirect = '';
    }
    if (isset($prometheus_Main_Settings['redirect_url'])) {
        $redirect_url = $prometheus_Main_Settings['redirect_url'];
    } else {
        $redirect_url = '';
    }
    if (isset($prometheus_Main_Settings['rich_editor'])) {
        $rich_editor = $prometheus_Main_Settings['rich_editor'];
    } else {
        $rich_editor = '';
    }
    if (isset($prometheus_Main_Settings['submit_status'])) {
        $submit_status = $prometheus_Main_Settings['submit_status'];
    } else {
        $submit_status = '';
    }
    if (isset($prometheus_Main_Settings['success_message'])) {
        $success_message = $prometheus_Main_Settings['success_message'];
    } else {
        $success_message = '';
    }
    if (isset($prometheus_Main_Settings['failed_message'])) {
        $failed_message = $prometheus_Main_Settings['failed_message'];
    } else {
        $failed_message = '';
    }
    if (isset($prometheus_Main_Settings['unique_title'])) {
        $unique_title = $prometheus_Main_Settings['unique_title'];
    } else {
        $unique_title = '';
    }
    if (isset($prometheus_Main_Settings['email_alert'])) {
        $email_alert = $prometheus_Main_Settings['email_alert'];
    } else {
        $email_alert = '';
    }
    if (isset($prometheus_Main_Settings['email_alert_address'])) {
        $email_alert_address = $prometheus_Main_Settings['email_alert_address'];
    } else {
        $email_alert_address = '';
    }
    if (isset($prometheus_Main_Settings['redirect_url_fail'])) {
        $redirect_url_fail = $prometheus_Main_Settings['redirect_url_fail'];
    } else {
        $redirect_url_fail = '';
    }
    if (isset($prometheus_Main_Settings['redirect_to_post'])) {
        $redirect_to_post = $prometheus_Main_Settings['redirect_to_post'];
    } else {
        $redirect_to_post = '';
    }
    if (isset($prometheus_Main_Settings['spam_protect'])) {
        $spam_protect = $prometheus_Main_Settings['spam_protect'];
    } else {
        $spam_protect = '';
    }
    if (isset($prometheus_Main_Settings['ban_names'])) {
        $ban_names = $prometheus_Main_Settings['ban_names'];
    } else {
        $ban_names = '';
    }
    if (isset($prometheus_Main_Settings['censor_words'])) {
        $censor_words = $prometheus_Main_Settings['censor_words'];
    } else {
        $censor_words = '';
    }
    if (isset($prometheus_Main_Settings['html_after'])) {
        $html_after = $prometheus_Main_Settings['html_after'];
    } else {
        $html_after = '';
    }
    if (isset($prometheus_Main_Settings['html_before'])) {
        $html_before = $prometheus_Main_Settings['html_before'];
    } else {
        $html_before = '';
    }
    if (isset($prometheus_Main_Settings['hide_curse'])) {
        $hide_curse = $prometheus_Main_Settings['hide_curse'];
    } else {
        $hide_curse = '';
    }
    if (isset($prometheus_Main_Settings['hide_after_success'])) {
        $hide_after_success = $prometheus_Main_Settings['hide_after_success'];
    } else {
        $hide_after_success = '';
    }
    if (isset($prometheus_Main_Settings['hide_after_fail'])) {
        $hide_after_fail = $prometheus_Main_Settings['hide_after_fail'];
    } else {
        $hide_after_fail = '';
    }
    if (isset($prometheus_Main_Settings['recaptcha_add'])) {
        $recaptcha_add = $prometheus_Main_Settings['recaptcha_add'];
    } else {
        $recaptcha_add = '';
    }
    if (isset($prometheus_Main_Settings['recaptcha_site_key'])) {
        $recaptcha_site_key = $prometheus_Main_Settings['recaptcha_site_key'];
    } else {
        $recaptcha_site_key = '';
    }
    if (isset($prometheus_Main_Settings['recaptcha_secret_key'])) {
        $recaptcha_secret_key = $prometheus_Main_Settings['recaptcha_secret_key'];
    } else {
        $recaptcha_secret_key = '';
    }
    if (isset($prometheus_Main_Settings['recaptcha_theme'])) {
        $recaptcha_theme = $prometheus_Main_Settings['recaptcha_theme'];
    } else {
        $recaptcha_theme = '';
    }
    if (isset($prometheus_Main_Settings['recaptcha_language'])) {
        $recaptcha_language = $prometheus_Main_Settings['recaptcha_language'];
    } else {
        $recaptcha_language = '';
    }
    if (isset($prometheus_Main_Settings['captcha_spam'])) {
        $captcha_spam = $prometheus_Main_Settings['captcha_spam'];
    } else {
        $captcha_spam = '';
    }
    if (isset($prometheus_Main_Settings['captcha_incorrect'])) {
        $captcha_incorrect = $prometheus_Main_Settings['captcha_incorrect'];
    } else {
        $captcha_incorrect = '';
    }
    if (isset($prometheus_Main_Settings['post_excerpt'])) {
        $post_excerpt = $prometheus_Main_Settings['post_excerpt'];
    } else {
        $post_excerpt = '';
    }
    if (isset($prometheus_Main_Settings['post_type'])) {
        $post_type = $prometheus_Main_Settings['post_type'];
    } else {
        $post_type = '';
    }
    if (isset($prometheus_Main_Settings['accept_comments'])) {
        $accept_comments = $prometheus_Main_Settings['accept_comments'];
    } else {
        $accept_comments = '';
    }
    if (isset($prometheus_Main_Settings['ping_status'])) {
        $ping_status = $prometheus_Main_Settings['ping_status'];
    } else {
        $ping_status = '';
    }
    if (isset($prometheus_Main_Settings['password'])) {
        $password = $prometheus_Main_Settings['password'];
    } else {
        $password = '';
    }
    if (isset($prometheus_Main_Settings['post_format'])) {
        $post_format = $prometheus_Main_Settings['post_format'];
    } else {
        $post_format = '';
    }
    if (isset($prometheus_Main_Settings['extra_info'])) {
        $extra_info = $prometheus_Main_Settings['extra_info'];
    } else {
        $extra_info = '';
    }
    if (isset($prometheus_Main_Settings['unique_content'])) {
        $unique_content = $prometheus_Main_Settings['unique_content'];
    } else {
        $unique_content = '';
    }
    if (isset($prometheus_Main_Settings['default_title'])) {
        $default_title = $prometheus_Main_Settings['default_title'];
    } else {
        $default_title = '';
    }
    if (isset($prometheus_Main_Settings['default_type'])) {
        $default_type = $prometheus_Main_Settings['default_type'];
    } else {
        $default_type = '';
    }
    if (isset($prometheus_Main_Settings['default_tags'])) {
        $default_tags = $prometheus_Main_Settings['default_tags'];
    } else {
        $default_tags = '';
    }
    if (isset($prometheus_Main_Settings['default_content'])) {
        $default_content = $prometheus_Main_Settings['default_content'];
    } else {
        $default_content = '';
    }
    if (isset($prometheus_Main_Settings['default_excerpt'])) {
        $default_excerpt = $prometheus_Main_Settings['default_excerpt'];
    } else {
        $default_excerpt = '';
    }
    if (isset($prometheus_Main_Settings['default_category'])) {
        $default_category = $prometheus_Main_Settings['default_category'];
    } else {
        $default_category = '';
    }
    if (isset($prometheus_Main_Settings['default_comment'])) {
        $default_comment = $prometheus_Main_Settings['default_comment'];
    } else {
        $default_comment = '';
    }
    if (isset($prometheus_Main_Settings['default_ping'])) {
        $default_ping = $prometheus_Main_Settings['default_ping'];
    } else {
        $default_ping = '';
    }
    if (isset($prometheus_Main_Settings['default_password'])) {
        $default_password = $prometheus_Main_Settings['default_password'];
    } else {
        $default_password = '';
    }
    if (isset($prometheus_Main_Settings['default_format'])) {
        $default_format = $prometheus_Main_Settings['default_format'];
    } else {
        $default_format = '';
    }
    if (isset($prometheus_Main_Settings['multiple_categories'])) {
        $multiple_categories = $prometheus_Main_Settings['multiple_categories'];
    } else {
        $multiple_categories = '';
    }
    if (isset($prometheus_Main_Settings['allow_names'])) {
        $allow_names = $prometheus_Main_Settings['allow_names'];
    } else {
        $allow_names = '';
    }
    if (isset($prometheus_Main_Settings['save_failed_submit'])) {
        $save_failed_submit = $prometheus_Main_Settings['save_failed_submit'];
    } else {
        $save_failed_submit = '';
    }
    if (isset($prometheus_Main_Settings['user_categories'])) {
        $user_categories = $prometheus_Main_Settings['user_categories'];
    } else {
        $user_categories = '';
    }
    if (isset($prometheus_Main_Settings['min_chars_content'])) {
        $min_chars_content = $prometheus_Main_Settings['min_chars_content'];
    } else {
        $min_chars_content = '';
    }
    if (isset($prometheus_Main_Settings['max_chars_content'])) {
        $max_chars_content = $prometheus_Main_Settings['max_chars_content'];
    } else {
        $max_chars_content = '';
    }
    if (isset($prometheus_Main_Settings['min_chars_title'])) {
        $min_chars_title = $prometheus_Main_Settings['min_chars_title'];
    } else {
        $min_chars_title = '';
    }
    if (isset($prometheus_Main_Settings['max_chars_title'])) {
        $max_chars_title = $prometheus_Main_Settings['max_chars_title'];
    } else {
        $max_chars_title = '';
    }
    if (isset($prometheus_Main_Settings['min_chars_other'])) {
        $min_chars_other = $prometheus_Main_Settings['min_chars_other'];
    } else {
        $min_chars_other = '';
    }
    if (isset($prometheus_Main_Settings['max_chars_other'])) {
        $max_chars_other = $prometheus_Main_Settings['max_chars_other'];
    } else {
        $max_chars_other = '';
    }
    if (isset($prometheus_Main_Settings['auto_tags'])) {
        $auto_tags = $prometheus_Main_Settings['auto_tags'];
    } else {
        $auto_tags = '';
    }
    if (isset($prometheus_Main_Settings['more_files'])) {
        $more_files = $prometheus_Main_Settings['more_files'];
    } else {
        $more_files = '';
    }
    if (isset($prometheus_Main_Settings['max_files'])) {
        $max_files = $prometheus_Main_Settings['max_files'];
    } else {
        $max_files = '';
    }
    if (isset($prometheus_Main_Settings['max_file_size'])) {
        $max_file_size = $prometheus_Main_Settings['max_file_size'];
    } else {
        $max_file_size = '';
    }
    if (isset($prometheus_Main_Settings['min_file_size'])) {
        $min_file_size = $prometheus_Main_Settings['min_file_size'];
    } else {
        $min_file_size = '';
    }
    if (isset($prometheus_Main_Settings['min_files'])) {
        $min_files = $prometheus_Main_Settings['min_files'];
    } else {
        $min_files = '';
    }
    if (isset($prometheus_Main_Settings['allowed_extension'])) {
        $allowed_extension = $prometheus_Main_Settings['allowed_extension'];
    } else {
        $allowed_extension = '';
    }
    if (isset($prometheus_Main_Settings['max_width'])) {
        $max_width = $prometheus_Main_Settings['max_width'];
    } else {
        $max_width = '';
    }
    if (isset($prometheus_Main_Settings['min_width'])) {
        $min_width = $prometheus_Main_Settings['min_width'];
    } else {
        $min_width = '';
    }
    if (isset($prometheus_Main_Settings['min_height'])) {
        $min_height = $prometheus_Main_Settings['min_height'];
    } else {
        $min_height = '';
    }
    if (isset($prometheus_Main_Settings['max_height'])) {
        $max_height = $prometheus_Main_Settings['max_height'];
    } else {
        $max_height = '';
    }
    if (isset($prometheus_Main_Settings['admin_notice'])) {
        $admin_notice = $prometheus_Main_Settings['admin_notice'];
    } else {
        $admin_notice = '';
    }
    if (isset($prometheus_Main_Settings['max_urls'])) {
        $max_urls = $prometheus_Main_Settings['max_urls'];
    } else {
        $max_urls = '';
    }
    if (isset($prometheus_Main_Settings['allow_html'])) {
        $allow_html = $prometheus_Main_Settings['allow_html'];
    } else {
        $allow_html = '';
    }
    if (isset($prometheus_Main_Settings['allow_drag'])) {
        $allow_drag = $prometheus_Main_Settings['allow_drag'];
    } else {
        $allow_drag = '';
    }
    if (isset($prometheus_Main_Settings['add_media'])) {
        $add_media = $prometheus_Main_Settings['add_media'];
    } else {
        $add_media = '';
    }
    if (isset($prometheus_Main_Settings['auto_include'])) {
        $auto_include = $prometheus_Main_Settings['auto_include'];
    } else {
        $auto_include = '';
    }
    if (isset($prometheus_Main_Settings['insert_only_images'])) {
        $insert_only_images = $prometheus_Main_Settings['insert_only_images'];
    } else {
        $insert_only_images = '';
    }
    if (isset($prometheus_Main_Settings['link_images'])) {
        $link_images = $prometheus_Main_Settings['link_images'];
    } else {
        $link_images = '';
    }
    if (isset($prometheus_Main_Settings['featured_image'])) {
        $featured_image = $prometheus_Main_Settings['featured_image'];
    } else {
        $featured_image = '';
    }
    if (isset($prometheus_Main_Settings['image_width'])) {
        $image_width = $prometheus_Main_Settings['image_width'];
    } else {
        $image_width = '';
    }
    if (isset($prometheus_Main_Settings['image_height'])) {
        $image_height = $prometheus_Main_Settings['image_height'];
    } else {
        $image_height = '';
    }
    if (isset($prometheus_Main_Settings['sender_email_address'])) {
        $sender_email_address = $prometheus_Main_Settings['sender_email_address'];
    } else {
        $sender_email_address = '';
    }
    if (isset($prometheus_Main_Settings['email_subject'])) {
        $email_subject = $prometheus_Main_Settings['email_subject'];
    } else {
        $email_subject = '';
    }
    if (isset($prometheus_Main_Settings['email_content'])) {
        $email_content = $prometheus_Main_Settings['email_content'];
    } else {
        $email_content = '';
    }
    if (isset($prometheus_Main_Settings['wrap_fieldset'])) {
        $wrap_fieldset = $prometheus_Main_Settings['wrap_fieldset'];
    } else {
        $wrap_fieldset = '';
    }
    if (isset($prometheus_Main_Settings['form_theme'])) {
        $form_theme = $prometheus_Main_Settings['form_theme'];
    } else {
        $form_theme = '';
    }
    if (isset($prometheus_Main_Settings['form_color'])) {
        $form_color = $prometheus_Main_Settings['form_color'];
    } else {
        $form_color = '';
    }
    if (isset($prometheus_Main_Settings['fieldset_border'])) {
        $fieldset_border = $prometheus_Main_Settings['fieldset_border'];
    } else {
        $fieldset_border = '';
    }
    if (isset($prometheus_Main_Settings['fieldset_color'])) {
        $fieldset_color = $prometheus_Main_Settings['fieldset_color'];
    } else {
        $fieldset_color = '';
    }
    if (isset($prometheus_Main_Settings['border_width'])) {
        $border_width = $prometheus_Main_Settings['border_width'];
    } else {
        $border_width = '';
    }
    if (isset($prometheus_Main_Settings['form_border_width'])) {
        $form_border_width = $prometheus_Main_Settings['form_border_width'];
    } else {
        $form_border_width = '';
    }
    if (isset($prometheus_Main_Settings['form_border'])) {
        $form_border = $prometheus_Main_Settings['form_border'];
    } else {
        $form_border = '';
    }
    if (isset($prometheus_Main_Settings['font_type'])) {
        $font_type = $prometheus_Main_Settings['font_type'];
    } else {
        $font_type = '';
    }
    if (isset($prometheus_Main_Settings['font_size'])) {
        $font_size = $prometheus_Main_Settings['font_size'];
    } else {
        $font_size = '';
    }
    if (isset($prometheus_Main_Settings['font_color'])) {
        $font_color = $prometheus_Main_Settings['font_color'];
    } else {
        $font_color = '';
    }
    if (isset($prometheus_Main_Settings['bold_fonts'])) {
        $bold_fonts = $prometheus_Main_Settings['bold_fonts'];
    } else {
        $bold_fonts = '';
    }
    if (isset($prometheus_Main_Settings['italic_fonts'])) {
        $italic_fonts = $prometheus_Main_Settings['italic_fonts'];
    } else {
        $italic_fonts = '';
    }
    if (isset($prometheus_Main_Settings['underline_fonts'])) {
        $underline_fonts = $prometheus_Main_Settings['underline_fonts'];
    } else {
        $underline_fonts = '';
    }
    if (isset($prometheus_Main_Settings['form_transparent'])) {
        $form_transparent = $prometheus_Main_Settings['form_transparent'];
    } else {
        $form_transparent = '';
    }
    if (isset($prometheus_Main_Settings['fieldset_transparent'])) {
        $fieldset_transparent = $prometheus_Main_Settings['fieldset_transparent'];
    } else {
        $fieldset_transparent = '';
    }
    if (isset($prometheus_Main_Settings['custom_css'])) {
        $custom_css = $prometheus_Main_Settings['custom_css'];
    } else {
        $custom_css = '';
    }
?>
<script>
                var prometheus_admin_json = {
                    prometheus_enabled: '<?php
    echo $prometheus_enabled;
?>',
                    need_login: '<?php
    echo $need_login;
?>',
                    need_login_message: '<?php
    echo $need_login_message;
?>',
                    anon_users_name: '<?php
    echo $anon_users_name;
?>',
                    user_name: '<?php
    echo $user_name;
?>',
                    user_email: '<?php
    echo $user_email;
?>',
                    user_url: '<?php
    echo $user_url;
?>',
                    post_title: '<?php
    echo $post_title;
?>',
                    post_tags: '<?php
    echo $post_tags;
?>',
                    post_category: '<?php
    echo $post_category;
?>',
                    post_captcha: '<?php
    echo $post_captcha;
?>',
                    post_content: '<?php
    echo $post_content;
?>',
                    post_image: '<?php
    echo $post_image;
?>',
                    captcha_question: '<?php
    echo $captcha_question;
?>',
                    captcha_answer: '<?php
    echo $captcha_answer;
?>',
                    redirect: '<?php
    echo $redirect;
?>',
                    redirect_url: '<?php
    echo $redirect_url;
?>',
                    rich_editor: '<?php
    echo $rich_editor;
?>',
                    submit_status: '<?php
    echo $submit_status;
?>',
                    success_message: '<?php
    echo $success_message;
?>',
                    failed_message: '<?php
    echo $failed_message;
?>',
                    unique_title: '<?php
    echo $unique_title;
?>',
                    email_alert: '<?php
    echo $email_alert;
?>',
                    email_alert_address: '<?php
    echo $email_alert_address;
?>',
                    redirect_url_fail: '<?php
    echo $redirect_url_fail;
?>',
                    redirect_to_post: '<?php
    echo $redirect_to_post;
?>',
                    spam_protect: '<?php
    echo $spam_protect;
?>',
                    ban_names: '<?php
    echo $ban_names;
?>',
                    censor_words: '<?php
    echo $censor_words;
?>',
                    html_before: '<?php
    echo $html_before;
?>',
                    html_after: '<?php
    echo $html_after;
?>',
                    hide_curse: '<?php
    echo $hide_curse;
?>',
                    hide_after_fail: '<?php
    echo $hide_after_fail;
?>',
                    hide_after_success: '<?php
    echo $hide_after_success;
?>',
                    recaptcha_add: '<?php
    echo $recaptcha_add;
?>',
                    recaptcha_site_key: '<?php
    echo $recaptcha_site_key;
?>',
                    recaptcha_secret_key: '<?php
    echo $recaptcha_secret_key;
?>',
                    recaptcha_language: '<?php
    echo $recaptcha_language;
?>',
                    recaptcha_theme: '<?php
    echo $recaptcha_theme;
?>',
                    captcha_incorrect: '<?php
    echo $captcha_incorrect;
?>',
                    captcha_spam: '<?php
    echo $captcha_spam;
?>',
                    post_excerpt: '<?php
    echo $post_excerpt;
?>',
                    post_type: '<?php
    echo $post_type;
?>',
                    accept_comments: '<?php
    echo $accept_comments;
?>',
                    ping_status: '<?php
    echo $ping_status;
?>',
                    password: '<?php
    echo $password;
?>',
                    post_format: '<?php
    echo $post_format;
?>',
                    extra_info: '<?php
    echo $extra_info;
?>',
                    unique_content: '<?php
    echo $unique_content;
?>',
                    default_title: '<?php
    echo $default_title;
?>',
                    default_tags: '<?php
    echo $default_tags;
?>',
                    default_content: '<?php
    echo $default_content;
?>',
                    default_category: '<?php
    echo $default_category;
?>',
                    default_excerpt: '<?php
    echo $default_excerpt;
?>',
                    default_type: '<?php
    echo $default_type;
?>',
                    default_comment: '<?php
    echo $default_comment;
?>',
                    default_ping: '<?php
    echo $default_ping;
?>',
                    default_password: '<?php
    echo $default_password;
?>',
                    default_format: '<?php
    echo $default_format;
?>',
                    multiple_categories: '<?php
    echo $multiple_categories;
?>',
                    allow_names: '<?php
    echo $allow_names;
?>',
                    save_failed_submit: '<?php
    echo $save_failed_submit;
?>',
                    user_categories: '<?php
    echo $user_categories;
?>',
                    max_chars_other: '<?php
    echo $max_chars_other;
?>',
                    min_chars_other: '<?php
    echo $min_chars_other;
?>',
                    max_chars_title: '<?php
    echo $max_chars_title;
?>',
                    min_chars_title: '<?php
    echo $min_chars_title;
?>',
                    max_chars_content: '<?php
    echo $max_chars_content;
?>',
                    min_chars_content: '<?php
    echo $min_chars_content;
?>',
                    auto_tags: '<?php
    echo $auto_tags;
?>',
                    more_files: '<?php
    echo $more_files;
?>',
                    max_files: '<?php
    echo $max_files;
?>',
                    min_file_size: '<?php
    echo $min_file_size;
?>',
                    max_file_size: '<?php
    echo $max_file_size;
?>',
                    min_files: '<?php
    echo $min_files;
?>',
                    allowed_extension: '<?php
    echo $allowed_extension;
?>',
                    max_height: '<?php
    echo $max_height;
?>',
                    min_height: '<?php
    echo $min_height;
?>',
                    min_width: '<?php
    echo $min_width;
?>',
                    max_width: '<?php
    echo $max_width;
?>',
                    admin_notice: '<?php
    echo $admin_notice;
?>',
                    max_urls: '<?php
    echo $max_urls;
?>',
                    allow_html: '<?php
    echo $allow_html;
?>',
                    allow_drag: '<?php
    echo $allow_drag;
?>',
                    add_media: '<?php
    echo $add_media;
?>',
                    auto_include: '<?php
    echo $auto_include;
?>',
                    insert_only_images: '<?php
    echo $insert_only_images;
?>',
                    link_images: '<?php
    echo $link_images;
?>',
                    featured_image: '<?php
    echo $featured_image;
?>',
                    image_height: '<?php
    echo $image_height;
?>',
                    image_width: '<?php
    echo $image_width;
?>',
                    sender_email_address: '<?php
    echo $sender_email_address;
?>',
                    email_content: '<?php
    echo $email_content;
?>',
                    email_subject: '<?php
    echo $email_subject;
?>',
                    wrap_fieldset: '<?php
    echo $wrap_fieldset;
?>',
                    form_theme: '<?php
    echo $form_theme;
?>',
                    form_color: '<?php
    echo $form_color;
?>',
                    fieldset_border: '<?php
    echo $fieldset_border;
?>',
                    fieldset_color: '<?php
    echo $fieldset_color;
?>',
                    border_width: '<?php
    echo $border_width;
?>',
                    form_border: '<?php
    echo $form_border;
?>',
                    form_border_width: '<?php
    echo $form_border_width;
?>',
                    font_type: '<?php
    echo $font_type;
?>',
                    font_size: '<?php
    echo $font_size;
?>',
                    bold_fonts: '<?php
    echo $bold_fonts;
?>',
                    italic_fonts: '<?php
    echo $italic_fonts;
?>',
                    underline_fonts: '<?php
    echo $underline_fonts;
?>',
                    font_color: '<?php
    echo $font_color;
?>',
                    form_transparent: '<?php
    echo $form_transparent;
?>',
                    fieldset_transparent: '<?php
    echo $fieldset_transparent;
?>',
                    custom_css: '<?php
    echo preg_replace("/[\r\n]+/", " ", htmlspecialchars($custom_css));
?>',
}
</script>
<script type="text/javascript">
    
    function toggleWords()
    {
        if(jQuery('#switchHide').is(":visible"))
        {            
            jQuery(".switchHide").hide();
        }
        else
        {
            jQuery(".switchHide").show();
        }
    }
    function toggleCats()
    {
        if(jQuery('#hideCats').is(":visible"))
        {            
            jQuery(".hideCats").hide();
        }
        else
        {
            jQuery(".hideCats").show();
        }
    }
    function toggleCats2()
    {
        if(jQuery('#hideCats2').is(":visible"))
        {            
            jQuery(".hideCats2").hide();
        }
        else
        {
            jQuery(".hideCats2").show();
        }
    }
    
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('#need_login').is(":checked"))
        {            
            jQuery(".hideReg").show();
            jQuery(".hideReg2").hide();
        }
        else
        {
            jQuery(".hideReg").hide();
            jQuery(".hideReg2").show();
        }
        if(jQuery('#redirect').is(":checked"))
        {            
            jQuery(".hideRed").show();
        }
        else
        {
            jQuery(".hideRed").hide();
        }
        if(jQuery('#email_alert').is(":checked"))
        {            
            jQuery(".hideMail").show();
        }
        else
        {
            jQuery(".hideMail").hide();
        }
        if(jQuery('select[id=submit_status]').val() == 'publish')
        {            
            jQuery(".hidePost").show();
        }
        else
        {
            jQuery(".hidePost").hide();
        }
        if(jQuery('select[id=form_theme]').val() == 'custom')
        {            
            jQuery(".hideCustom").show();
            jQuery(".hideCustom2").hide();
        }
        else
        {
            if(jQuery('select[id=form_theme]').val() == 'own')
            { 
                jQuery(".hideCustom2").show();
                jQuery(".hideCustom").hide();
            }
            else
            {
                jQuery(".hideCustom2").hide();
                jQuery(".hideCustom").hide();
            }
        }
        if(jQuery('#hide_curse').is(":checked"))
        {            
            jQuery(".hideCur").show();
        }
        else
        {
            jQuery(".hideCur").hide();
        }
        if(jQuery('#recaptcha_add').is(":checked"))
        {            
            jQuery(".hideRec").show();
        }
        else
        {
            jQuery(".hideRec").hide();
        }
        if(jQuery('#rich_editor').is(":checked"))
        {            
            jQuery(".hideEditor").show();
        }
        else
        {
            jQuery(".hideEditor").hide();
        }
        toggleWords();
        toggleCats();
        toggleCats2();
    }
    window.onload = mainChanged;
</script>
<div ng-app="prosettingsApp" ng-controller="prosettingsController" ng-cloak ng-init="initialized()">
<div class="prometheus_class">
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Prometheus User Submitted Content Plugin Main Switch:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Prometheus User Submitted Content Plugin. This acts like a main switch.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="prometheus_enabled" name="prometheus_Main_Settings[prometheus_enabled]" onChange="mainChanged()" <?php
    if ($prometheus_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="prometheus_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <table><tr><td>
                    <h3>User Posting Restrictions:</h3></td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to allow only logged in visitors to send posts?";
?>
                        </div>
                    </div>
                    <b>Allow Only Registered Users to Submit Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="need_login" name="prometheus_Main_Settings[need_login]" onChange="mainChanged()" <?php
    if ($need_login == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideReg">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Message to be shown to unregistered users. Basic HTML markup is allowed.";
?>
                        </div>
                    </div>
                    <b>'Only Registered Users Allowed' Message:</b>
                    </div>
                    </td><td>
                    <div class="hideReg">
                    <input type="text" name="prometheus_Main_Settings[need_login_message]" ng-model="settings.need_login_message">
                    </div>
                    </td></tr><tr><td>
        <div class="hideReg">
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose which user categories can submit posts with the submission form. User roles in WordPress are (in ascending rights order): Subscribers, Contributors, Authors, Editors and Administrators.";
?>
                        </div>
                    </div>
                    <b>User Categories Allowed to Submit Posts:</b>
                    </div>
                    </td><td>
                    <div class="hideReg">
                    <select id="user_categories" name="prometheus_Main_Settings[user_categories]" >
                                  <option value="0"<?php
    if ($user_categories == "0") {
        echo " selected";
    }
?>>Nobody</option>
                                  <option value="1"<?php
    if ($user_categories == "1") {
        echo " selected";
    }
?>>Only Administrators</option>
                                  <option value="2"<?php
    if ($user_categories == "2") {
        echo " selected";
    }
?>>Editors and Administrators</option>
                                    <option value="3"<?php
    if ($user_categories == "3") {
        echo " selected";
    }
?>>Authors, Editors and Administrators</option>
                                  <option value="4"<?php
    if ($user_categories == "4") {
        echo " selected";
    }
?>>Contributors, Authors, Editors and Administrators</option>
                                    <option value="5"<?php
    if ($user_categories == "5") {
        echo " selected";
    }
?>>Everybody</option>
                    </select>    
</div>                    
        </div>
                    </td></tr><tr><td>
        <div class="hideReg2">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>User Name for Anonymous User Posts:</b>
                    </div>
                    </td><td>
                    <div class="hideReg2">
                    <select id="anon_users_name" name="prometheus_Main_Settings[anon_users_name]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($anon_users_name == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
                    <br/>
                    </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to allow users to submit more files at once?";
?>
                        </div>
                    </div>
                    <b>Allow Users to Submit More Than 1 File at Once:</b>
                    
                    </td><td>
                    <input type="checkbox" id="more_files" name="prometheus_Main_Settings[more_files]" <?php
    if ($more_files == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the maximum number of files a user can submit. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Files a User Can Submit:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_files]" ng-model="settings.max_files" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the minimum number of files a user can submit. Leave this field blank, to disable the limitation. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Minimum Number of Files a User Can Submit:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[min_files]" ng-model="settings.min_files" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the maximum file size that you allow users to submit. Leave the textfield blank or set it to 0, if you do not want to have a maximum. The number is set in bytes. 1024b = 1Kb, 1048576b = 1Mb";
?>
                        </div>
                    </div>
                    <b>Maximum File Size for Submitted Files:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_file_size]" ng-model="settings.max_file_size" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the minimum file size that you allow users to submit. Leave the textfield blank or set it to 0, if you do not want to have a minimum. The number is set in bytes. 1024b = 1Kb, 1048576b = 1Mb";
?>
                        </div>
                    </div>
                    <b>Minimum File Size for Submitted Files:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[min_file_size]" ng-model="settings.min_file_size" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the allowed file extensions for the files your users submit. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Allowed File Extensions for Submission:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[allowed_extension]" ng-model="settings.allowed_extension">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the maximum width for image files. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Image Maximum Width:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_width]" ng-model="settings.max_width" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the minimum width for image files. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Image Minimum Width:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[min_width]" ng-model="settings.min_width" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the maximum height for image files. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Image Maximum Height:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_height]" ng-model="settings.max_height" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the minimum height for image files. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Image Minimum Height:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[min_height]" ng-model="settings.min_height" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Maximum number of URLs in post content. Leave this field blank, to disable the limitation.";
?>
                        </div>
                    </div>
                    <b>Maximum Number of URLs in Post Content:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_urls]" ng-model="settings.max_urls" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to allow HTML in post content.";
?>
                        </div>
                    </div>
                    <b>Allow HTML in Post Content:</b>
                    </td><td>
                    <input type="checkbox" id="allow_html" name="prometheus_Main_Settings[allow_html]" <?php
    if ($allow_html == 'on')
        echo ' checked ';
?>>                      
        </div>
                    </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Ban users login names from submitting posts. You can enter more user login names in this field, all separated by a comma.";
?>
                        </div>
                    </div>
                    <b>Ban Users Names From Submitting Posts:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[ban_names]" ng-model="settings.ban_names">
                    </div>
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Allow only these user login names to submit posts. You can enter more user login names in this field, all separated by a comma.";
?>
                        </div>
                    </div>
                    <b>Allow Only These Users Names to Submit Posts:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[allow_names]" ng-model="settings.allow_names">
                    </div>
                    
                    </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Enable the list of categories you want to show to you visitors that are submitting posts.";
?>
                        </div>
                    </div>
                    <b>Categories to Show to Submitters:</b>
                    <a href="" onclick="toggleCats()">Show/Hide Categories List</a>
                    </td><td>
                    <br/>
                    <div id="hideCats" class="hideCats">
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($prometheus_Main_Settings['enabled_categories']) && !empty($prometheus_Main_Settings['enabled_categories'])) {
            checked(true, in_array($category->term_id, $prometheus_Main_Settings['enabled_categories']));
        }
?>
 type="checkbox" name="prometheus_Main_Settings[enabled_categories][]" value="<?php
        echo $category->term_id;
?>" /> 
														<span><?php
        echo sanitize_text_field($category->name);
?></span>
													</label>
												</div>
<?php
    }
?>

        </div>
        </div>
        <br/>

        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The minimum number of characters that the submitted post titles should have. 0 means no minimum.";
?>
                        </div>
                    </div>
                    <b>Minimum Number of Characters for the Post Title:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[min_chars_title]" ng-model="settings.min_chars_title" pattern="^[0-9]+$">
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The maximum number of characters that the submitted post titles should have. 0 means no maximum.";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Characters for the Post Title:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_chars_title]" ng-model="settings.max_chars_title" pattern="^[0-9]+$">
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The minimum number of characters that the submitted post content should have. 0 means no minimum.";
?>
                        </div>
                    </div>
                    <b>Minimum Number of Characters for the Post Content:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[min_chars_content]" ng-model="settings.min_chars_content" pattern="^[0-9]+$">
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The maximum number of characters that the submitted post content should have. 0 means no maximum.";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Characters for the Post Content:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_chars_content]" ng-model="settings.max_chars_content" pattern="^[0-9]+$">
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The minimum number of characters that other text fields (excluding post title and post content) should have. 0 means no minimum. Affected fields are: author name, email address, author URL, post tags, post excerpt and post password.";
?>
                        </div>
                    </div>
                    <b>Minimum Number of Characters for Other Text Fields:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[min_chars_other]" ng-model="settings.min_chars_other" pattern="^[0-9]+$">
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The maximum number of characters that other text fields (excluding post title and post content) should have. 0 means no maximum. Affected fields are: author name, email address, author URL, post tags, post excerpt and post password.";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Characters for Other Text Fields:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[max_chars_other]" ng-model="settings.max_chars_other" pattern="^[0-9]+$">
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to require unique post titles (useful for preventing duplicate submits)?";
?>
                        </div>
                    </div>
                    <b>Require Unique Post Titles:</b>
                    
                    </td><td>
                    <input type="checkbox" id="unique_title" name="prometheus_Main_Settings[unique_title]"<?php
    if ($unique_title == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to require unique post content (useful for preventing duplicate submits)?";
?>
                        </div>
                    </div>
                    <b>Require Unique Post Content:</b>
                    
                    </td><td>
                    <input type="checkbox" id="unique_content" name="prometheus_Main_Settings[unique_content]"<?php
    if ($unique_content == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <h3>General Plugin Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the user published posts to have, after submission.";
?>
                        </div>
                    </div>
                    <b>Post Status After Submission:</b>                  
                    </td><td>
                    <select id="submit_status" name="prometheus_Main_Settings[submit_status]" onChange="mainChanged()" >
                                  <option value="pending"<?php
    if ($submit_status == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add any file type to posts? If you want to add only images to posts, uncheck this checkbox.";
?>
                        </div>
                    </div>
                    <b>Automatically Insert Any File Type in Posts:</b>
                    </td><td>
                    <input type="checkbox" id="insert_only_images" name="prometheus_Main_Settings[insert_only_images]" <?php
    if ($insert_only_images == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to add a link to inserted images? The link will open the full size image in a new tab.";
?>
                        </div>
                    </div>
                    <b>Add Link to the Added Images Pointing to the Full Size Image:</b>
                    </td><td>
                    <input type="checkbox" id="link_images" name="prometheus_Main_Settings[link_images]" <?php
    if ($link_images == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to generate a featured image for the post, from the first submitted image file?";
?>
                        </div>
                    </div>
                    <b>Auto Set Featured Image for Submitted Post:</b>
                    </td><td>
                    <input type="checkbox" id="featured_image" name="prometheus_Main_Settings[featured_image]" <?php
    if ($featured_image == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Width of the image to be included in the post.";
?>
                        </div>
                    </div>
                    <b>Automatically Added Image Width:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[image_width]" ng-model="settings.image_width" pattern="^[0-9]+$">    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Height of the image to be included in the post.";
?>
                        </div>
                    </div>
                    <b>Automatically Added Image Height:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[image_height]" ng-model="settings.image_height" pattern="^[0-9]+$">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to add to your form a hidden text field to act as an extra spammer bot protection security messure?";
?>
                        </div>
                    </div>
                    <b>Enable Spammer Bot Protection:</b>
                    
                    </td><td>
                    <input type="checkbox" id="spam_protect" name="prometheus_Main_Settings[spam_protect]"<?php
    if ($spam_protect == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable admin panel notices when new posts arrive?";
?>
                        </div>
                    </div>
                    <b>Enable Admin Panel Notices for New Posts:</b>
                    </td><td>
                    <input type="checkbox" id="admin_notice" name="prometheus_Main_Settings[admin_notice]" <?php
    if ($admin_notice == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to get an email alert every time a new post is submitted to your webpage?";
?>
                        </div>
                    </div>
                    <b>Enable Email Alerts on New Post Submission:</b>
                    <?php
    $mailResult = false;
    $mailResult = wp_mail('you@example.com', 'How are you', 'Hurray');
    echo $mailResult ? '<div class="tooltip">Mail sending OK!
  <span class="tooltiptext">Automatic test e-mail was sent! Mail sending is working!</span>
</div>' : '<div class="tooltip">Issue detected!
  <span class="tooltiptext">Automatic test email cannot be sent! Please verify your WordPress e-mailing feature configuration!</span>
</div>';
?>
                    </td><td>
                    <input type="checkbox" id="email_alert" name="prometheus_Main_Settings[email_alert]" onChange="mainChanged()" <?php
    if ($email_alert == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideMail">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The email address where to send the new post messages. You can enter multiple email adresses, each separated by a comma from the other.";
?>
                        </div>
                    </div>
                    <b>Email Address Where to Send the New Post Messages:</b>
                    </div>
                    </td><td>
                    <div class="hideMail">
                    <input type="email" name="prometheus_Main_Settings[email_alert_address]" ng-model="settings.email_alert_address">
                    </div>
        </td></tr><tr><td>
        <div class="hideMail">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The FROM Address in the sent email. You can enter only one email adress. You can enter an inexistent email adress (noreply@yourdomain.com)";
?>
                        </div>
                    </div>
                    <b>The Sender Email Adress:</b>
                    </div>
                    </td><td>
                    <div class="hideMail">
                    <input type="email" name="prometheus_Main_Settings[sender_email_address]" ng-model="settings.sender_email_address">
                    </div>
        </td></tr><tr><td>
        <div class="hideMail">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The Subject of the sent email. You can also use the following shortcodes: %%post_title%%, %%post_content%%, post_excerpt%%, %%post_status%%, %%post_author%%, %%post_type%%, %%post_password%%, %%tags%%, category%%, %%author%%, %%author_email%%, %%author_url%%, %%author_user_agent%%, %%author_ip%%, %%author_referrer%%, %%sitename%%, %%siteurl%%, %%permalink%%, %%editlink%%";
?>
                        </div>
                    </div>
                    <b>Email Subject:</b>
                    </div>
                    </td><td>
                    <div class="hideMail">
                    <input type="text" name="prometheus_Main_Settings[email_subject]" ng-model="settings.email_subject">
                    </div>
        </td></tr><tr><td>
        <div class="hideMail">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The content of the sent email. You can also use the following shortcodes: %%post_title%%, %%post_content%%, post_excerpt%%, %%post_status%%, %%post_author%%, %%post_type%%, %%post_password%%, %%tags%%, category%%, %%author%%, %%author_email%%, %%author_url%%, %%author_user_agent%%, %%author_ip%%, %%author_referrer%%, %%sitename%%, %%siteurl%%, %%permalink%%, %%editlink%%";
?>
                        </div>
                    </div>
                    <b>Email Content:</b>
                    </div>
                    </td><td>
                    <div class="hideMail">
                    <input type="text" name="prometheus_Main_Settings[email_content]" ng-model="settings.email_content">
                    </div>
                    </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to hide the submission form after a successful post submit?";
?>
                        </div>
                    </div>
                    <b>Hide Form After a Successful Form Submission:</b>                  
                    </td><td>
                    <input type="checkbox" id="hide_after_success" name="prometheus_Main_Settings[hide_after_success]"<?php
    if ($hide_after_success == 'on')
        echo ' checked ';
?>>                   
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to hide the submission form after a failed post submit?";
?>
                        </div>
                    </div>
                    <b>Hide Form After a Failed Form Submission:</b>                  
                    </td><td>
                    <input type="checkbox" id="hide_after_fail" name="prometheus_Main_Settings[hide_after_fail]"<?php
    if ($hide_after_fail == 'on')
        echo ' checked ';
?>>                   
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to save input textfield values after a failed submit attempt? If you leave this checkbox unchecked, you form security will be increased, but you risk to annoy your users.";
?>
                        </div>
                    </div>
                    <b>Save Textfileds Value After Failed Submit Attempt:</b>                  
                    </td><td>
                    <input type="checkbox" id="save_failed_submit" name="prometheus_Main_Settings[save_failed_submit]"<?php
    if ($save_failed_submit == 'on')
        echo ' checked ';
?>>                   
        </div>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Auto include these categories for the submitted posts.";
?>
                        </div>
                    </div>
                    <b>Categories to Automatically Include for the Submitted Posts:</b>
                    <a href="" onclick="toggleCats2()">Show/Hide Categories List</a>
                    </td><td>
                    <br/>
                    <div id="hideCats2" class="hideCats2">
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
												<div>
													<label>
														<input
<?php
        if (isset($prometheus_Main_Settings['auto_categories']) && !empty($prometheus_Main_Settings['auto_categories'])) {
            checked(true, in_array($category->term_id, $prometheus_Main_Settings['auto_categories']));
        }
?>
 type="checkbox" name="prometheus_Main_Settings[auto_categories][]" value="<?php
        echo $category->term_id;
?>" /> 
														<span><?php
        echo sanitize_text_field($category->name);
?></span>
													</label>
												</div>
<?php
    }
?>
        </div>
        </div>
        <br/>
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Automatically add these tags to submitted posts. You can add more tags, each separated by a comma.";
?>
                        </div>
                    </div>
                    <b>Automatically Add These Tags to Submitted Posts:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[auto_tags]" ng-model="settings.auto_tags">
                    </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to redirect users to a custom page after they submit their post?";
?>
                        </div>
                    </div>
                    <b>Redirect Users after Form Submission:</b>
                    
                    </td><td>
                    <input type="checkbox" id="redirect" name="prometheus_Main_Settings[redirect]" onChange="mainChanged()" <?php
    if ($redirect == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideRed">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Where do you want to redirct users after a successful form submission?";
?>
                        </div>
                    </div>
                    <b>Redirect Users after Submit Success URL:</b>
                    </div>
                    </td><td>
                    <div class="hideRed">
                    <input type="url" validator="url" name="prometheus_Main_Settings[redirect_url]" ng-model="settings.redirect_url">
                    </div>
                    </td></tr><tr><td>
        <div class="hideRed">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Where do you want to redirct users after a failed form submission?";
?>
                        </div>
                    </div>
                    <b>Redirect Users after Submit Fail URL:</b>
                    </div>
                    </td><td>
                    <div class="hideRed">
                    <input type="url" validator="url" name="prometheus_Main_Settings[redirect_url_fail]" ng-model="settings.redirect_url_fail">
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="hidePost">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to redirect users to their published post after they hit submit? Note that this option only applies if you set that posts are automatically published after user submission.";
?>
                        </div>
                    </div>
                    <b>Redirect Users to Their Published Post:</b>
</div>                    
                    </td><td>
                    <div class="hidePost">
                    <input type="checkbox" id="redirect_to_post" name="prometheus_Main_Settings[redirect_to_post]" <?php
    if ($redirect_to_post == 'on')
        echo ' checked ';
?>>
</div>                    
        </div>
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The message to be shown after successful form submission. Leave blank for the default messages to appear.";
?>
                        </div>
                    </div>
                    <b>Successful Form Submission Message:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[success_message]" ng-model="settings.success_message">
        </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The message to be shown at a failed form submission. Leave blank for the default messages to appear. This message will suppress all other error messages! So set it to be as general as possible.";
?>
                        </div>
                    </div>
                    <b>Failed Form Submission Message:</b>
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[failed_message]" ng-model="settings.failed_message">
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to gather some extra information (IP, User Agent, Referrer) from those who submitted posts to your website?";
?>
                        </div>
                    </div>
                    <b>Gather Extra Information from Submitters:</b>
                    
                    </td><td>
                    <input type="checkbox" id="extra_info" name="prometheus_Main_Settings[extra_info]" <?php
    if ($extra_info == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically show submitted files in posts?";
?>
                        </div>
                    </div>
                    <b>Automatically Include Submitted Files in Posts:</b>
                    
                    </td><td>
                    <select id="auto_include" name="prometheus_Main_Settings[auto_include]" >
                                  <option value="begin"<?php
    if ($auto_include == "begin") {
        echo " selected";
    }
?>>Post Beginning</option>
                                  <option value="end"<?php
    if ($auto_include == "end") {
        echo " selected";
    }
?>>Post Ending</option>
                                  <option value="none"<?php
    if ($auto_include == "none") {
        echo " selected";
    }
?>>No Auto Include</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable censoring of curse words?";
?>
                        </div>
                    </div>
                    <b>Enable Curse Words Filtering:</b>                  
                    </td><td>
                    <input type="checkbox" id="hide_curse" name="prometheus_Main_Settings[hide_curse]" onChange="mainChanged()" <?php
    if ($hide_curse == 'on')
        echo ' checked ';
?>>                   
        </div>
        </td></tr><tr><td>
        <div class="hideCur">
        <a href="" onclick="toggleWords()">Show/Hide Censored Words List</a>
        <div id="switchHide" class="switchHide">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Censor these a list of words when they appear in the submitted post title or content. They will be replaced with * (stars).";
?>
                        </div>
                    </div>
                    <b>Censor These Words When Appearing in the Post:</b>
                    </div>
                    </div>
                    </td><td>
                    <div class="hideCur">
                    <div class="switchHide">
                    <textarea rows="5" cols="70" type="text" name="prometheus_Main_Settings[censor_words]" ng-model="settings.censor_words"></textarea>
                    </div>
                    </div>
                    </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <h3>Input Fields Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show username input in your form?";
?>
                        </div>
                    </div>
                    <b>User Name Input Field:</b>
                    
                    </td><td>
                    <select id="user_name" name="prometheus_Main_Settings[user_name]" >
                                  <option value="ShowRequire"<?php
    if ($user_name == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($user_name == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($user_name == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show user email input in your form?";
?>
                        </div>
                    </div>
                    <b>User Email Input Field:</b>
                    
                    </td><td>
                    <select id="user_email" name="prometheus_Main_Settings[user_email]" >
                                  <option value="ShowRequire"<?php
    if ($user_email == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($user_email == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($user_email == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show user URL input in your form?";
?>
                        </div>
                    </div>
                    <b>User URL Input Field:</b>
                    
                    </td><td>
                    <select id="user_url" name="prometheus_Main_Settings[user_url]" >
                                  <option value="ShowRequire"<?php
    if ($user_url == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($user_url == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($user_url == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show post title input in your form?";
?>
                        </div>
                    </div>
                    <b>Post Title Input Field:</b>
                    
                    </td><td>
                    <select id="post_title" name="prometheus_Main_Settings[post_title]" >
                                  <option value="ShowRequire"<?php
    if ($post_title == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_title == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_title == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show post tags input in your form?";
?>
                        </div>
                    </div>
                    <b>Post Tags Input Field:</b>
                    
                    </td><td>
                    <select id="post_tags" name="prometheus_Main_Settings[post_tags]" >
                                  <option value="ShowRequire"<?php
    if ($post_tags == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_tags == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_tags == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show post category input in your form?";
?>
                        </div>
                    </div>
                    <b>Post Category Input Field:</b>
                    
                    </td><td>
                    <select id="post_category" name="prometheus_Main_Settings[post_category]" >
                                  <option value="ShowRequire"<?php
    if ($post_category == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_category == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_category == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show post content input in your form?";
?>
                        </div>
                    </div>
                    <b>Post Content Input Field:</b>
                    
                    </td><td>
                    <select id="post_content" name="prometheus_Main_Settings[post_content]" >
                                  <option value="ShowRequire"<?php
    if ($post_content == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_content == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_content == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show a captcha input in your form?";
?>
                        </div>
                    </div>
                    <b>Post Captcha Input Field:</b>
                    
                    </td><td>
                    <select id="post_captcha" name="prometheus_Main_Settings[post_captcha]" > 
                                  <option value="ShowRequire"<?php
    if ($post_captcha == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Hide"<?php
    if ($post_captcha == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show an excerpt input in your form?";
?>
                        </div>
                    </div>
                    <b>Post Excerpt Input Field:</b>
                    
                    </td><td>
                    <select id="post_excerpt" name="prometheus_Main_Settings[post_excerpt]" >
                                  <option value="ShowRequire"<?php
    if ($post_excerpt == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_excerpt == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_excerpt == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to let your users select if they want to enable comments on their submitted post?";
?>
                        </div>
                    </div>
                    <b>Post Comment Selection Input Field:</b>
                    
                    </td><td>
                    <select id="accept_comments" name="prometheus_Main_Settings[accept_comments]" >
                                  <option value="ShowRequire"<?php
    if ($accept_comments == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($accept_comments == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($accept_comments == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to let your users select if they want to enable pings on their submitted post?";
?>
                        </div>
                    </div>
                    <b>Post Ping Selection Input Field:</b>
                    
                    </td><td>
                    <select id="ping_status" name="prometheus_Main_Settings[ping_status]" >
                                  <option value="ShowRequire"<?php
    if ($ping_status == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($ping_status == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($ping_status == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to let your users select if they want to set a password on their submitted post? Warning! Use this field with caution! Setting a password on a post, will deny access to it!";
?>
                        </div>
                    </div>
                    <b>Post Password Selection Input Field:</b>
                    
                    </td><td>
                    <select id="password" name="prometheus_Main_Settings[password]" >
                                  <option value="ShowRequire"<?php
    if ($password == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($password == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($password == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to let your visitors choose what type of post format do they want to apply to their submitted posts?";
?>
                        </div>
                    </div>
                    <b>Post Format Selection Input Field:</b>
                    
                    </td><td>
                    <select id="post_format" name="prometheus_Main_Settings[post_format]" >
                                  <option value="ShowRequire"<?php
    if ($post_format == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_format == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_format == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to let your users select if they want to submit a new post or a new page.";
?>
                        </div>
                    </div>
                    <b>Post/Page Type Selection Input Field:</b>
                    
                    </td><td>
                    <select id="post_type" name="prometheus_Main_Settings[post_type]" >
                                  <option value="ShowRequire"<?php
    if ($post_type == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_type == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_type == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show an image upload input in your form?";
?>
                        </div>
                    </div>
                    <b>Post Image Upload Input Field:</b>
                    
                    </td><td>
                    <select id="post_image" name="prometheus_Main_Settings[post_image]" >
                                  <option value="ShowRequire"<?php
    if ($post_image == "ShowRequire") {
        echo " selected";
    }
?>>Show and Require</option>
                                  <option value="Show"<?php
    if ($post_image == "Show") {
        echo " selected";
    }
?>>Show</option>
                                  <option value="Hide"<?php
    if ($post_image == "Hide") {
        echo " selected";
    }
?>>Hide</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to allow users to select multiple categories for submitted posts?";
?>
                        </div>
                    </div>
                    <b>Allow Multiple Categories Selection:</b>
                    
                    </td><td>
                    <input type="checkbox" id="multiple_categories" name="prometheus_Main_Settings[multiple_categories]" <?php
    if ($multiple_categories == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideCapt">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The Captcha question to be shown to the form users. This can be a secret question that only a limited number of people will know.";
?>
                        </div>
                    </div>
                    <b>Built-In Captcha Question to be Shown:</b>
                    </div>
                    </td><td>
                    <div class="hideCapt">
                    <input type="text" name="prometheus_Main_Settings[captcha_question]" ng-model="settings.captcha_question">
                    </div>
                    </td></tr><tr><td>
        <div class="hideCapt">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The Captcha answer to be required from the form users. Warning! Case sensitive!";
?>
                        </div>
                    </div>
                    <b>Built-In Captcha Answer Required:</b>
                    </div>
                    </td><td>
                    <div class="hideCapt">
                    <input type="text" name="prometheus_Main_Settings[captcha_answer]" ng-model="settings.captcha_answer">
                    </div>
                    </td></tr><tr><td>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to add a Google ReCaptcha to the form?";
?>
                    </div>
                    </div>
                    <b>Enable Google ReCaptcha Integrition:</b>
                    </div>
                    </td><td>
                    <input type="checkbox" id="recaptcha_add" name="prometheus_Main_Settings[recaptcha_add]" onChange="mainChanged()" <?php
    if ($recaptcha_add == 'on')
        echo ' checked ';
?>>
</td></tr><tr><td>
        <div class="hideRec">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please <a href='https://www.google.com/recaptcha/admin#list' target='_blank'>register your blog through the Google reCAPTCHA admin page</a> and enter the site key in the fields below. <a href='https://developers.google.com/recaptcha/intro' target='_blank'>More help.</a>";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Site Key:</b>
                    </div>
                    </td><td>
                    <div class="hideRec">
                    <input type="text" name="prometheus_Main_Settings[recaptcha_site_key]" ng-model="settings.recaptcha_site_key">
                    </div>
                    </td></tr><tr><td>
        <div class="hideRec">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Please <a href='https://www.google.com/recaptcha/admin#list' target='_blank'>register your blog through the Google reCAPTCHA admin page</a> and enter the secret key in the fields below. <a href='https://developers.google.com/recaptcha/intro' target='_blank'>More help.</a>";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Secret Key:</b>
                    </div>
                    </td><td>
                    <div class="hideRec">
                    <input type="text" name="prometheus_Main_Settings[recaptcha_secret_key]" ng-model="settings.recaptcha_secret_key">
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="hideRec">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the theme you would like to apply to the recaptchas. You can select between light or dark. Note that some themes rely on the 'Wrap Input Fields With Fieldset:' option and will not work if this option is not enabled!";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Theme:</b>
                    </div>
                    </td><td>
                    <div class="hideRec">
                    <select id="recaptcha_theme" name="prometheus_Main_Settings[recaptcha_theme]" >
                                  <option value="Light"<?php
    if ($recaptcha_theme == "Light") {
        echo " selected";
    }
?>>Light</option>
                                  <option value="Dark"<?php
    if ($recaptcha_theme == "Dark") {
        echo " selected";
    }
?>>Dark</option>
                    </select>  
                        </div>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideRec">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the language you would like to apply to the recaptchas.";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Language:</b>
                    </div>
                    </td><td>
                    <div class="hideRec">
                    <select id="recaptcha_language" name="prometheus_Main_Settings[recaptcha_language]">
                                  <option value="ar"<?php
    if ($recaptcha_language == "ar") {
        echo " selected";
    }
?>>Arabic</option>
                                  <option value="bg"<?php
    if ($recaptcha_language == "bg") {
        echo " selected";
    }
?>>Bulgarian</option>
                                  <option value="ca"<?php
    if ($recaptcha_language == "ca") {
        echo " selected";
    }
?>>Catalan</option>
                                  <option value="zh-CN"<?php
    if ($recaptcha_language == "zh-CN") {
        echo " selected";
    }
?>>Chinese (Simplified)</option>
                                  <option value="zh-TW"<?php
    if ($recaptcha_language == "zh-TW") {
        echo " selected";
    }
?>>Chinese (Traditional)</option>
                                  <option value="hr"<?php
    if ($recaptcha_language == "hr") {
        echo " selected";
    }
?>>Croatian</option>
                                  <option value="cs"<?php
    if ($recaptcha_language == "ar") {
        echo " selected";
    }
?>>Czech</option>
                                  <option value="da"<?php
    if ($recaptcha_language == "da") {
        echo " selected";
    }
?>>Danish</option>
                                  <option value="nl"<?php
    if ($recaptcha_language == "nl") {
        echo " selected";
    }
?>>Dutch</option>
                                  <option value="en-GB"<?php
    if ($recaptcha_language == "en-GB") {
        echo " selected";
    }
?>>English (UK)</option>
                                  <option value="en"<?php
    if ($recaptcha_language == "en") {
        echo " selected";
    }
?>>English (US)</option>
                                  <option value="fil"<?php
    if ($recaptcha_language == "fil") {
        echo " selected";
    }
?>>Filipino</option>
                                  <option value="fi"<?php
    if ($recaptcha_language == "fi") {
        echo " selected";
    }
?>>Finnish</option>
                                  <option value="fr"<?php
    if ($recaptcha_language == "fr") {
        echo " selected";
    }
?>>French</option>
                                  <option value="fr-CA"<?php
    if ($recaptcha_language == "fr-CA") {
        echo " selected";
    }
?>>French (Canadian)</option>
                                  <option value="de"<?php
    if ($recaptcha_language == "de") {
        echo " selected";
    }
?>>German</option>
                                  <option value="de-AT"<?php
    if ($recaptcha_language == "de-AT") {
        echo " selected";
    }
?>>German (Austria)</option>
                                  <option value="de-CH"<?php
    if ($recaptcha_language == "de-CH") {
        echo " selected";
    }
?>>German (Switzerland)</option>
                                  <option value="el"<?php
    if ($recaptcha_language == "el") {
        echo " selected";
    }
?>>Greek</option>
                                  <option value="iw"<?php
    if ($recaptcha_language == "iw") {
        echo " selected";
    }
?>>Hebrew</option>
                                  <option value="hi"<?php
    if ($recaptcha_language == "hi") {
        echo " selected";
    }
?>>Hindi</option>
                                  <option value="hu"<?php
    if ($recaptcha_language == "hu") {
        echo " selected";
    }
?>>Hungarain</option>
                                  <option value="id"<?php
    if ($recaptcha_language == "id") {
        echo " selected";
    }
?>>Indonesian</option>
                                  <option value="it"<?php
    if ($recaptcha_language == "it") {
        echo " selected";
    }
?>>Italian</option>
                                  <option value="ja"<?php
    if ($recaptcha_language == "ja") {
        echo " selected";
    }
?>>Japanese</option>
                                  <option value="ko"<?php
    if ($recaptcha_language == "ko") {
        echo " selected";
    }
?>>Korean</option>
                                  <option value="lv"<?php
    if ($recaptcha_language == "lv") {
        echo " selected";
    }
?>>Latvian</option>
                                  <option value="lt"<?php
    if ($recaptcha_language == "lt") {
        echo " selected";
    }
?>>Lithuanian</option>
                                  <option value="no"<?php
    if ($recaptcha_language == "no") {
        echo " selected";
    }
?>>Norwegian</option>
                                  <option value="fa"<?php
    if ($recaptcha_language == "fa") {
        echo " selected";
    }
?>>Persian</option>
                                  <option value="pl"<?php
    if ($recaptcha_language == "pl") {
        echo " selected";
    }
?>>Polish</option>
                                  <option value="pt"<?php
    if ($recaptcha_language == "pt") {
        echo " selected";
    }
?>>Portuguese</option>
                                  <option value="pt-BR"<?php
    if ($recaptcha_language == "pt-BR") {
        echo " selected";
    }
?>>Portuguese (Brazil)</option>
                                  <option value="pt-PT"<?php
    if ($recaptcha_language == "pt-PT") {
        echo " selected";
    }
?>>Portuguese (Portugal)</option>
                                  <option value="ro"<?php
    if ($recaptcha_language == "ro") {
        echo " selected";
    }
?>>Romanian</option>
                                  <option value="ru"<?php
    if ($recaptcha_language == "ru") {
        echo " selected";
    }
?>>Russian</option>
                                  <option value="sr"<?php
    if ($recaptcha_language == "sr") {
        echo " selected";
    }
?>>Serbian</option>
                                  <option value="sk"<?php
    if ($recaptcha_language == "sk") {
        echo " selected";
    }
?>>Slovak</option>
                                  <option value="sl"<?php
    if ($recaptcha_language == "sl") {
        echo " selected";
    }
?>>Slovenian</option>
                                  <option value="es"<?php
    if ($recaptcha_language == "es") {
        echo " selected";
    }
?>>Spanish</option>
                                  <option value="es-419"<?php
    if ($recaptcha_language == "es-419") {
        echo " selected";
    }
?>>Spanish (Latin America)</option>
                                  <option value="sv"<?php
    if ($recaptcha_language == "sv") {
        echo " selected";
    }
?>>Swedish</option>
                                  <option value="th"<?php
    if ($recaptcha_language == "th") {
        echo " selected";
    }
?>>Thai</option>
                                  <option value="tr"<?php
    if ($recaptcha_language == "tr") {
        echo " selected";
    }
?>>Turkish</option>
                                  <option value="uk"<?php
    if ($recaptcha_language == "uk") {
        echo " selected";
    }
?>>Ukrainian</option>
                                  <option value="vi"<?php
    if ($recaptcha_language == "vi") {
        echo " selected";
    }
?>>Vietnamese</option>
                    </select>  
               </div>         
        </div>
        </td></tr><tr><td>
        <div class="hideRec">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Message to be show to users when the captcha they enterred is incorrect.";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Incorrect Message:</b>
                    </div>
                    </td><td>
                    <div class="hideRec">
                    <input type="text" name="prometheus_Main_Settings[captcha_incorrect]" ng-model="settings.captcha_incorrect">
                    </div>
                    </td></tr><tr><td>
        <div class="hideRec">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Message to be show to users when the captcha they enterred is spam.";
?>
                        </div>
                    </div>
                    <b>ReCaptcha Spam Message:</b>
                    </div>
                    </td><td>
                    <div class="hideRec">
                    <input type="text" name="prometheus_Main_Settings[captcha_spam]" ng-model="settings.captcha_spam">
                    </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <h3>Default Values Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post title setting. This will apply only when you hide the title field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[default_title]" ng-model="settings.default_title">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post tags setting. This will apply only when you hide the tags field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[default_tags]" ng-model="settings.default_tags">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post content setting. This will apply only when you hide the content field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Content:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[default_content]" ng-model="settings.default_content">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post category setting. This will apply only when you hide the category field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Category:</b>
                    
                    </td><td>
                    <select id="default_category" name="prometheus_Main_Settings[default_category]" ng-model="settings.default_category">
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post excerpt setting. This will apply only when you hide the excerpt field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Excerpt:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[default_excerpt]" ng-model="settings.default_excerpt">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post type setting. This will apply only when you hide the type field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Type:</b>
                    
                    </td><td>
                    <select id="default_type" name="prometheus_Main_Settings[default_type]" ng-model="settings.default_type">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post comment setting. This will apply only when you hide the comment field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Comment Policy:</b>
                    
                    </td><td>
                    <select id="default_comment" name="prometheus_Main_Settings[default_comment]" ng-model="settings.default_comment">
                        <option value="open">Allow</option>
                        <option value="closed">Deny</option>
                    </select>  
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the ping setting. This will apply only when you hide the ping field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Ping Policy:</b>
                    
                    </td><td>
                    <select id="default_ping" name="prometheus_Main_Settings[default_ping]" ng-model="settings.default_ping">
                        <option value="open">Allow</option>
                        <option value="closed">Deny</option>
                    </select> 
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post password setting. This will apply only when you hide the password field. Leave it blank to disable it.";
?>
                        </div>
                    </div>
                    <b>Default Post Password:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[default_password]" ng-model="settings.default_password">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the default value for the post format setting. This will apply only when you hide the format field or you do not require it and the user leaves it blank.";
?>
                        </div>
                    </div>
                    <b>Default Post Format:</b>
                    
                    </td><td>
                    <select id="default_format" name="prometheus_Main_Settings[default_format]" ng-model="settings.default_format">
                        <option value="post-format-standard">Standard</option>
                        <option value="post-format-aside">Aside</option>
                        <option value="post-format-gallery">Gallery</option>
                        <option value="post-format-link">Link</option>
                        <option value="post-format-image">Image</option>
                        <option value="post-format-quote">Quote</option>
                        <option value="post-format-audio">Audio</option>
                        <option value="post-format-video">Video</option>
                        <option value="post-format-status">Status</option>
                        <option value="post-format-chat">Chat</option>
                    </select>                        
        </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        <h3>Display Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show rich text input field for post content editing or just a plain textfield?";
?>
                        </div>
                    </div>
                    <b>Show WordPress's Rich Text Editor For Post Content:</b>
                    
                    </td><td>
                    <input type="checkbox" id="rich_editor" name="prometheus_Main_Settings[rich_editor]" onChange="mainChanged()"<?php
    if ($rich_editor == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideEditor">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable 'Add Media' button in the rich text editor?";
?>
                        </div>
                    </div>
                    <b>Enable the 'Add Media' Button in the Rich Text Editor:</b>
                    </div>
                    </td><td>
                    <div class="hideEditor">
                    <input type="checkbox" id="add_media" name="prometheus_Main_Settings[add_media]" <?php
    if ($add_media == 'on')
        echo ' checked ';
?>>          
</div>            
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideEditor">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to allow drag and drop in the rich text editor?";
?>
                        </div>
                    </div>
                    <b>Allow Drag and Drop in Rich Text Editor:</b>
                    </div>
                    </td><td>
                    <div class="hideEditor">
                    <input type="checkbox" id="allow_drag" name="prometheus_Main_Settings[allow_drag]" <?php
    if ($allow_drag == 'on')
        echo ' checked ';
?>>         
</div>             
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Custom HTML markup to be included before the form.";
?>
                        </div>
                    </div>
                    <b>Custom HTML Before the Form:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[html_before]" ng-model="settings.html_before">
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Custom HTML markup to be included after the form.";
?>
                        </div>
                    </div>
                    <b>Custom HTML After the Form:</b>
                    
                    </td><td>
                    <input type="text" name="prometheus_Main_Settings[html_after]" ng-model="settings.html_after">
                        
        </div>
        
        
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to wrap every input field with fieldset?";
?>
                        </div>
                    </div>
                    <b>Wrap Input Fields With Fieldset:</b>
                    </td><td>
                    <input type="checkbox" id="wrap_fieldset" name="prometheus_Main_Settings[wrap_fieldset]" <?php
    if ($wrap_fieldset == 'on')
        echo ' checked ';
?>>                      
        </div>
        </td></tr><tr><td>
        <div>        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the theme of your submission form.";
?>
                        </div>
                    </div>
                    <b>Submission Form Theme:</b>
                    </td><td>
                    <select id="form_theme" name="prometheus_Main_Settings[form_theme]"  onchange="mainChanged()">
                                  <option value="theme"<?php
    if ($form_theme == "theme") {
        echo " selected";
    }
?>>Inherit From Theme</option>
                                  <option value="light"<?php
    if ($form_theme == "light") {
        echo " selected";
    }
?>>Light</option>
                                  <option value="dark"<?php
    if ($form_theme == "dark") {
        echo " selected";
    }
?>>Dark</option>
                                  <option value="blue"<?php
    if ($form_theme == "blue") {
        echo " selected";
    }
?>>Blue</option>
                                  <option value="red"<?php
    if ($form_theme == "red") {
        echo " selected";
    }
?>>Red</option>
                                  <option value="green"<?php
    if ($form_theme == "green") {
        echo " selected";
    }
?>>Green</option>
                                  <option value="transparent"<?php
    if ($form_theme == "transparent") {
        echo " selected";
    }
?>>Transparent</option>
                                  <option value="custom"<?php
    if ($form_theme == "custom") {
        echo " selected";
    }
?>>Custom</option>
                                  <option value="own"<?php
    if ($form_theme == "own") {
        echo " selected";
    }
?>>Own CSS</option>
                    </select>  
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom2">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input your custom CSS code.";
?>
                        </div>
                    </div>
                    <b>Custom CSS:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom2">
                    <textarea rows="12" cols="70" type="text" name="prometheus_Main_Settings[custom_css]" ng-model="settings.custom_css" ></textarea>
                        
        </div>
        </div>
        </td></tr><tr><td>
        <div> 
<div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the font type that you want to show in your form.";
?>
                        </div>
                    </div>
                    <b>Form Font Type:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <select id="font_type" name="prometheus_Main_Settings[font_type]" >
                                  <option value="Arial,Arial,Helvetica,sans-serif"<?php
    if ($font_type == "Arial,Arial,Helvetica,sans-serif") {
        echo " selected";
    }
?>>Arial,Arial,Helvetica,sans-serif</option>
<option value="Comic Sans MS,Comic Sans MS,cursive"<?php
    if ($font_type == "Comic Sans MS,Comic Sans MS,cursive") {
        echo " selected";
    }
?>>Comic Sans MS,Comic Sans MS,cursive</option>
<option value="Courier New,Courier New,Courier,monospace"<?php
    if ($font_type == "Courier New,Courier New,Courier,monospacee") {
        echo " selected";
    }
?>>Courier New,Courier New,Courier,monospace</option>
<option value="Georgia,Georgia,serif"<?php
    if ($font_type == "Georgia,Georgia,serif") {
        echo " selected";
    }
?>>Georgia,Georgia,serif</option>
<option value="Helvetica, Arial, sans-serif"<?php
    if ($font_type == "Helvetica, Arial, sans-serif") {
        echo " selected";
    }
?>>Helvetica, Arial, sans-serif</option>
<option value="Impact,Charcoal,sans-serif"<?php
    if ($font_type == "Impact,Charcoal,sans-serif") {
        echo " selected";
    }
?>>Impact,Charcoal,sans-serif</option>
<option value="Lucida Console,Monaco,monospace"<?php
    if ($font_type == "Lucida Console,Monaco,monospace") {
        echo " selected";
    }
?>>Lucida Console,Monaco,monospace</option>
<option value="Lucida Sans Unicode,Lucida Grande,sans-serif"<?php
    if ($font_type == "Lucida Sans Unicode,Lucida Grande,sans-serif") {
        echo " selected";
    }
?>>Lucida Sans Unicode,Lucida Grande,sans-serif</option>
<option value="Palatino Linotype,Book Antiqua,Palatino,serif"<?php
    if ($font_type == "Palatino Linotype,Book Antiqua,Palatino,serif") {
        echo " selected";
    }
?>>Palatino Linotype,Book Antiqua,Palatino,serif</option>
<option value="Tahoma,Geneva,sans-serif"<?php
    if ($font_type == "Tahoma,Geneva,sans-serif") {
        echo " selected";
    }
?>>Tahoma,Geneva,sans-serif</option>
<option value="Times New Roman,Times,serif"<?php
    if ($font_type == "Times New Roman,Times,serif") {
        echo " selected";
    }
?>>Times New Roman,Times,serif</option>
<option value="Trebuchet MS,Helvetica,sans-serif"<?php
    if ($font_type == "Trebuchet MS,Helvetica,sans-serif") {
        echo " selected";
    }
?>>Trebuchet MS,Helvetica,sans-serif</option>
<option value="Verdana,Geneva,sans-serif"<?php
    if ($font_type == "Verdana,Geneva,sans-serif") {
        echo " selected";
    }
?>>Verdana,Geneva,sans-serif</option>
<option value="Gill Sans,Geneva,sans-serif"<?php
    if ($font_type == "Gill Sans,Geneva,sans-serif") {
        echo " selected";
    }
?>>Gill Sans,Geneva,sans-serif</option>
                    </select> 
</div>                    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show bold fonts?";
?>
                        </div>
                    </div>
                    <b>Enable Bold Fonts:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="checkbox" id="bold_fonts" name="prometheus_Main_Settings[bold_fonts]" <?php
    if ($bold_fonts == 'on')
        echo ' checked ';
?>>          
</div>            
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show italic fonts?";
?>
                        </div>
                    </div>
                    <b>Enable Italic Fonts:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="checkbox" id="italic_fonts" name="prometheus_Main_Settings[italic_fonts]" <?php
    if ($italic_fonts == 'on')
        echo ' checked ';
?>>          
</div>            
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show underline fonts?";
?>
                        </div>
                    </div>
                    <b>Enable Underline Fonts:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="checkbox" id="underline_fonts" name="prometheus_Main_Settings[underline_fonts]" <?php
    if ($underline_fonts == 'on')
        echo ' checked ';
?>>          
</div>            
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to have transparent form background?";
?>
                        </div>
                    </div>
                    <b>Transparent Form Background:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="checkbox" id="form_transparent" name="prometheus_Main_Settings[form_transparent]" <?php
    if ($form_transparent == 'on')
        echo ' checked ';
?>>          
</div>            
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to have transparent fieldset background?";
?>
                        </div>
                    </div>
                    <b>Transparent Fieldset Background:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="checkbox" id="fieldset_transparent" name="prometheus_Main_Settings[fieldset_transparent]" <?php
    if ($fieldset_transparent == 'on')
        echo ' checked ';
?>>          
</div>            
        </div>
        </td></tr><tr><td>
        <div> 
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the size of the font.";
?>
                        </div>
                    </div>
                    <b>Form Font Size:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="text" name="prometheus_Main_Settings[font_size]" ng-model="settings.font_size" pattern="^[0-9]+$">
                    </div>
        </div>
        </td></tr><tr><td>
        <div> 
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the font color of the form.";
?>
                        </div>
                    </div>
                    <b>Form Font Color:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="color" name="prometheus_Main_Settings[font_color]" ng-model="settings.font_color">
                    </div>
        </div>
        </td></tr><tr><td>
        <div> 
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the background color of the form.";
?>
                        </div>
                    </div>
                    <b>Form Background Color:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="color" name="prometheus_Main_Settings[form_color]" ng-model="settings.form_color">
                    </div>
        </div>
        </td></tr><tr><td>
        <div> 
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the background color of the fieldsets in the form.";
?>
                        </div>
                    </div>
                    <b>Fieldsets Background Color:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="color" name="prometheus_Main_Settings[fieldset_color]" ng-model="settings.fieldset_color">
                    </div>
        </div>
        </td></tr><tr><td>
        <div> 
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the border color of the fieldsets in the form.";
?>
                        </div>
                    </div>
                    <b>Fieldsets Border Color:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="color" name="prometheus_Main_Settings[fieldset_border]" ng-model="settings.fieldset_border">
                    </div>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The width of the border of the fieldsets.";
?>
                        </div>
                    </div>
                    <b>Fieldset Border Width:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="text" name="prometheus_Main_Settings[border_width]" ng-model="settings.border_width" pattern="^[0-9]+$">
                        
        </div>
        </div>
        </td></tr><tr><td>
        <div> 
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the border color of the form in the form.";
?>
                        </div>
                    </div>
                    <b>Form Border Color:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="color" name="prometheus_Main_Settings[form_border]" ng-model="settings.form_border">
                    </div>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="hideCustom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The width of the border of the form.";
?>
                        </div>
                    </div>
                    <b>Form Border Width:</b>
                    </div>
                    </td><td>
                    <div class="hideCustom">
                    <input type="text" name="prometheus_Main_Settings[form_border_width]" ng-model="settings.form_border_width" pattern="^[0-9]+$">
                        
        </div>
        </div>
        </td></tr><tr><td><hr/></td><td><hr/></td></tr><tr><td>
        </td></tr></table>
        </div>
        </div>
        
<div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    <h3>Available Shortcodes:</h3>
    <p>Shortcode for adding the form in your content: <b>[prometheus_add_form]</b></p>
    <p>Shortcode for listing user submitted posts: <b>[prometheus_list_submitted_posts]</b></p>
    <p>Shortcode for listing user submitted pages: <b>[prometheus_list_submitted_pages]</b></p>
    <p>Shortcode for listing user submitted posts and pages: <b>[prometheus_list_submitted_posts_and_pages]</b></p>
    </form>
</div>
</div>
<?php
}
?>