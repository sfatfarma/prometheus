<?php
function prometheus_list_statistics($post)
{
    $ret        = '';
    $name       = get_post_meta($post->ID, 'author_name', true);
    $email      = get_post_meta($post->ID, 'author_email', true);
    $url        = get_post_meta($post->ID, 'author_url', true);
    $ip         = get_post_meta($post->ID, 'author_ip', true);
    $user_agent = get_post_meta($post->ID, 'author_user_agent', true);
    $referrer   = get_post_meta($post->ID, 'author_referrer', true);
    if (!empty($name) || !empty($email) || !empty($url) || !empty($ip) || !empty($user_agent) || !empty($referrer)) {
        $user = get_userdata(intval($post->post_author));
        $ret .= '<ul>';
        $ret .= '<li><b>Post Link:</b> <a href="' . get_permalink($post->ID) . '" target="_blank">' . get_permalink($post->ID) . '</a></li>';
        $ret .= '<li><b>Post ID:</b> ' . $post->ID . '</li>';
        $ret .= '<li><b>Post Author:</b> ' . $user->user_login . '</li>';
        $ret .= '<li><b>Post Name:</b> ' . $post->post_name . '</li>';
        $ret .= '<li><b>Post Type:</b> ' . $post->post_type . '</li>';
        $ret .= '<li><b>Post Title:</b> ' . $post->post_title . '</li>';
        $ret .= '<li><b>Post Date:</b> ' . $post->post_date . '</li>';
        $ret .= '<li><b>Post Status:</b> ' . $post->post_status . '</li>';
        $ret .= '<li><b>Post Password:</b> ' . $post->post_password . '</li>';
        $ret .= '<li><b>Comment Count:</b> ' . $post->comment_count . '</li>';
        if (!empty($name))
            $ret .= '<li><b>Author Submitted Name:</b> ' . $name . '</li>';
        if (!empty($email))
            $ret .= '<li><b>Author Email:</b> ' . $email . '</li>';
        if (!empty($url))
            $ret .= '<li><b>Author URL:</b> ' . $url . '</li>';
        if (!empty($ip))
            $ret .= '<li><b>Author IP:</b> ' . $ip . '</li>';
        if (!empty($user_agent))
            $ret .= '<li><b>Author User Agent:</b> ' . $user_agent . '</li>';
        if (!empty($referrer))
            $ret .= '<li><b>Author Referrer:</b> ' . $referrer . '</li>';
        $ret .= '</ul>';
    }
    return $ret;
}
function prometheus_statistics_page()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
<h3>Submitted Posts Statistics:</h3>
    <div>
<?php
    $nr        = 0;
    $ech       = '<ol>';
    $query     = array(
        'post_status' => array(
            'publish',
            'pending',
            'draft',
            'auto-draft',
            'future',
            'private',
            'inherit',
            'trash'
        ),
        'post_type' => array(
            'post',
            'page'
        )
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        if (get_post_meta($post->ID, 'prometheus_submitted_post', true) == 'true') {
            $ech .= '<li>' . prometheus_list_statistics($post) . '</li>';
            $nr++;
        }
    }
    if ($nr == 0) {
        $ech .= 'No posts or pages submitted!';
    }
    $ech .= '</ol>';
    echo $ech;
?>
</div>
</div>
<?php
}
?>