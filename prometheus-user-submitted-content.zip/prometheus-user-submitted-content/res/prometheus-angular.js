angular.module('prosettingsApp', ['ngSanitize'])
.controller('prosettingsController', function($scope) {
    $scope.settings = prometheus_admin_json;
});